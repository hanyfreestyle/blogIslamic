-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 23, 2024 at 05:56 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `islamic_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `blogcategory_blog`
--

CREATE TABLE `blogcategory_blog` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `blog_id` bigint(20) UNSIGNED NOT NULL,
  `postion` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blogcategory_blog`
--

INSERT INTO `blogcategory_blog` (`id`, `category_id`, `blog_id`, `postion`) VALUES
(1, 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `blog_categories`
--

CREATE TABLE `blog_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `old_id` int(11) DEFAULT NULL,
  `old_parent` int(11) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `deep` int(11) NOT NULL DEFAULT 0,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `postion` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_categories`
--

INSERT INTO `blog_categories` (`id`, `parent_id`, `old_id`, `old_parent`, `count`, `deep`, `icon`, `photo`, `photo_thum_1`, `is_active`, `postion`, `created_at`, `updated_at`) VALUES
(1, NULL, 29, 0, 4895, 0, NULL, NULL, NULL, 1, 0, '2024-07-17 05:30:04', '2024-07-17 05:30:04'),
(2, NULL, 121, 0, 76, 0, NULL, NULL, NULL, 1, 0, '2024-07-17 05:30:04', '2024-07-17 05:30:04'),
(3, NULL, 122, 0, 14, 0, NULL, NULL, NULL, 1, 0, '2024-07-17 05:30:04', '2024-07-17 05:30:04'),
(4, NULL, 123, 0, 22, 0, NULL, NULL, NULL, 1, 0, '2024-07-17 05:30:04', '2024-07-17 05:30:04'),
(5, NULL, 124, 0, 14, 0, NULL, NULL, NULL, 1, 0, '2024-07-17 05:30:04', '2024-07-17 05:30:04'),
(6, NULL, 15175, 0, 205, 0, NULL, NULL, NULL, 1, 0, '2024-07-17 05:30:04', '2024-07-17 05:30:04'),
(7, NULL, 15176, 0, 6, 0, NULL, NULL, NULL, 1, 0, '2024-07-17 05:30:04', '2024-07-17 05:30:04'),
(8, NULL, 17092, 0, 143, 0, NULL, NULL, NULL, 1, 0, '2024-07-17 05:30:04', '2024-07-17 05:30:04'),
(9, NULL, 40828, 0, 0, 0, NULL, NULL, NULL, 1, 0, '2024-07-17 05:30:04', '2024-07-17 05:30:04');

-- --------------------------------------------------------

--
-- Table structure for table `blog_category_translations`
--

CREATE TABLE `blog_category_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_category_translations`
--

INSERT INTO `blog_category_translations` (`id`, `category_id`, `locale`, `slug`, `name`, `des`, `g_title`, `g_des`) VALUES
(1, 1, 'ar', 'تفسير-الاحلام-لابن-سيرين', 'تفسير الاحلام لابن سيرين', '', 'تفسير الاحلام لابن سيرين', ''),
(2, 2, 'ar', 'تفسير-الأحلام-فهد-العصيمي', 'تفسير الأحلام فهد العصيمي', '', 'تفسير الأحلام فهد العصيمي', ''),
(3, 3, 'ar', 'تفسير-الأحلام-لابن-شاهين', 'تفسير الأحلام لابن شاهين', '', 'تفسير الأحلام لابن شاهين', ''),
(4, 4, 'ar', 'تفسير-الاحلام-للإمام-الصادق', 'تفسير الاحلام للإمام الصادق', '', 'تفسير الاحلام للإمام الصادق', ''),
(5, 5, 'ar', 'تفسير-الاحلام-للنابلسي', 'تفسير الاحلام للنابلسي', '', 'تفسير الاحلام للنابلسي', ''),
(6, 6, 'ar', 'تجربتي', 'تجربتي', '', 'تجربتي', ''),
(7, 7, 'ar', 'أسئلة-وحلول', 'أسئلة وحلول', '', 'أسئلة وحلول', ''),
(8, 8, 'ar', 'معلومات-عامة', 'معلومات عامة', '', 'معلومات عامة', ''),
(9, 9, 'ar', 'معلومات-طبية', 'معلومات طبية', '', 'معلومات طبية', '');

-- --------------------------------------------------------

--
-- Table structure for table `blog_post`
--

CREATE TABLE `blog_post` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `old_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published_at` date DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `view_count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_post`
--

INSERT INTO `blog_post` (`id`, `old_id`, `user_id`, `is_active`, `photo`, `photo_thum_1`, `published_at`, `deleted_at`, `created_at`, `updated_at`, `view_count`) VALUES
(1, NULL, 1, 1, NULL, NULL, '2024-07-23', NULL, '2024-07-23 09:10:42', '2024-07-23 09:10:42', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `blog_post_review`
--

CREATE TABLE `blog_post_review` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `blog_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `loop_index` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_post_review`
--

INSERT INTO `blog_post_review` (`id`, `user_id`, `blog_id`, `name`, `des`, `loop_index`, `updated_at`) VALUES
(1, 1, 1, NULL, NULL, 1, '2023-06-23 12:10:42'),
(2, 1, 1, 'مقال جديد', '<p>رؤية الدود يخرج من إصبع اليد في الحلم تثير مشاعر عدم الراحة والقلق. يمكن أن تشير هذه الرؤيا إلى وجود مشكلات أو استياء خفي يؤرق الشخص ويضغط على نفسيته، مما يحتم عليه مواجهة هذه الصعوبات. في بعض الحالات، ترمز هذه الرؤية إلى الرغبة في التخلص من عادات أو أفكار ضارة تؤثر سلبًا على حياة الفرد، وتحث على التغيير نحو الأفضل والتحلي بالتفاؤل والإيجابية لضمان تحقيق توازن نفسي وصحي أفضل. يعتقد بعض المفسرين أن خروج الدود من اليد اليمنى يحمل بشارة بالتخلص من المتاعب والأحزان قريبًا وبلوغ الأهداف المنشودة. بينما قد يعتبر خروجه من اليد اليسرى تحذيرًا يدعو للانتباه إلى الهموم والمشكلات المحتملة</p>\r\n\r\n<p>&nbsp;</p>', 2, '2023-07-23 12:12:26'),
(3, 1, 1, 'مقال جديد', '<p>رؤية الدود يخرج من إصبع اليد في الحلم تثير مشاعر عدم الراحة والقلق. يمكن أن تشير هذه الرؤيا إلى وجود مشكلات أو استياء خفي يؤرق الشخص ويضغط على نفسيته، مما يحتم عليه مواجهة هذه الصعوبات. في بعض الحالات، ترمز هذه الرؤية إلى الرغبة في التخلص من عادات أو أفكار ضارة تؤثر سلبًا على حياة الفرد، وتحث على التغيير نحو الأفضل والتحلي بالتفاؤل والإيجابية لضمان تحقيق توازن نفسي وصحي أفضل. يعتقد بعض المفسرين أن خروج الدود من اليد اليمنى يحمل بشارة بالتخلص من المتاعب والأحزان قريبًا وبلوغ الأهداف المنشودة. بينما قد يعتبر خروجه من اليد اليسرى تحذيرًا يدعو للانتباه إلى الهموم والمشكلات المحتملة</p>\r\n\r\n<p>تفسير رؤية الدود يخرج من الجسد في المنام لابن سيرين خروج الدود من الجسم في الأحلام يعد كإشارة إلى التحديات والأزمات النفسية التي يمكن أن يواجهها الإنسان. فإذا حلم شخص أن الدود يمر من جسده، فهذا يمكن أن يُعبّر عن الضغوط والمشاكل العاطفية أو النفسية التي يعاني منها. وعندما يخرج الدود من مناطق خاصة كفتحة الشرج في الحلم، قد يحمل هذا معاني تتعلّق بالنسل والعائلة. بمعنى آخر، قد يوحي هذا بأن الحالم سيشهد تطورات إيجابية في حياته الأسرية أو زيادة في عدد أفراد عائلته. أما رؤية الدود في فم الحالم تعد كعلامة على عدم الاستقرار النفسي أو العاطفي.<br />\r\n<br />\r\n&nbsp;</p>\r\n\r\n<p>&nbsp;</p>', 3, '2024-03-23 12:13:27'),
(4, 1, 1, 'مقال جديد', '<p>رؤية الدود يخرج من إصبع اليد في الحلم تثير مشاعر عدم الراحة والقلق. يمكن أن تشير هذه الرؤيا إلى وجود مشكلات أو استياء خفي يؤرق الشخص ويضغط على نفسيته، مما يحتم عليه مواجهة هذه الصعوبات. في بعض الحالات، ترمز هذه الرؤية إلى الرغبة في التخلص من عادات أو أفكار ضارة تؤثر سلبًا على حياة الفرد، وتحث على التغيير نحو الأفضل والتحلي بالتفاؤل والإيجابية لضمان تحقيق توازن نفسي وصحي أفضل. يعتقد بعض المفسرين أن خروج الدود من اليد اليمنى يحمل بشارة بالتخلص من المتاعب والأحزان قريبًا وبلوغ الأهداف المنشودة. بينما قد يعتبر خروجه من اليد اليسرى تحذيرًا يدعو للانتباه إلى الهموم والمشكلات المحتملة</p>\r\n\r\n<p>تفسير رؤية الدود يخرج من الجسد في المنام لابن سيرين خروج الدود من الجسم في الأحلام يعد كإشارة إلى التحديات والأزمات النفسية التي يمكن أن يواجهها الإنسان. فإذا حلم شخص أن الدود يمر من جسده، فهذا يمكن أن يُعبّر عن الضغوط والمشاكل العاطفية أو النفسية التي يعاني منها. وعندما يخرج الدود من مناطق خاصة كفتحة الشرج في الحلم، قد يحمل هذا معاني تتعلّق بالنسل والعائلة. بمعنى آخر، قد يوحي هذا بأن الحالم سيشهد تطورات إيجابية في حياته الأسرية أو زيادة في عدد أفراد عائلته. أما رؤية الدود في فم الحالم تعد كعلامة على عدم الاستقرار النفسي أو العاطفي.</p>\r\n\r\n<p>تفسير حلم خروج الدود من اليد اليمنى لابن سيرين في تأويلات ابن سيرين حول الأحلام، يُعتبر ظهور الدود من اليد اليمنى علامة مبشرة بالخير. يُشير إلى إمكانية الحصول على ثروة مادية كبيرة في المستقبل القريب، مما يؤدي إلى حياة أكثر رفاهية للشخص الذي يرى هذا الحلم. من جانب آخر، إذا رأى الشخص الدود يخرج من يده ويأكل من جسده، قد يدل ذلك على ولادة أبناء صالحين ومباركين في حياته. هذه رؤية تدعو الشخص للتفاؤل والاهتمام بتربية أبنائه تربية تقوم على المبادئ الدينية والأخلاق الحميدة. كما أن حلم الدود الذي يخرج بكثرة من اليد يعد بشارة بالتقدم والترقية في المستقبل القريب.<br />\r\n<br />\r\n&nbsp;</p>\r\n\r\n<p>&nbsp;</p>', 4, '2024-05-11 12:14:56'),
(5, 1, 1, 'مقال جديد', '<p>رؤية الدود يخرج من إصبع اليد في الحلم تثير مشاعر عدم الراحة والقلق. يمكن أن تشير هذه الرؤيا إلى وجود مشكلات أو استياء خفي يؤرق الشخص ويضغط على نفسيته، مما يحتم عليه مواجهة هذه الصعوبات. في بعض الحالات، ترمز هذه الرؤية إلى الرغبة في التخلص من عادات أو أفكار ضارة تؤثر سلبًا على حياة الفرد، وتحث على التغيير نحو الأفضل والتحلي بالتفاؤل والإيجابية لضمان تحقيق توازن نفسي وصحي أفضل. يعتقد بعض المفسرين أن خروج الدود من اليد اليمنى يحمل بشارة بالتخلص من المتاعب والأحزان قريبًا وبلوغ الأهداف المنشودة. بينما قد يعتبر خروجه من اليد اليسرى تحذيرًا يدعو للانتباه إلى الهموم والمشكلات المحتملة</p>\r\n\r\n<h2>تفسير رؤية الدود يخرج من الجسد في المنام لابن سيرين خروج الدود من الجسم في الأحلام</h2>\r\n\r\n<p>يعد كإشارة إلى التحديات والأزمات النفسية التي يمكن أن يواجهها الإنسان. فإذا حلم شخص أن الدود يمر من جسده، فهذا يمكن أن يُعبّر عن الضغوط والمشاكل العاطفية أو النفسية التي يعاني منها. وعندما يخرج الدود من مناطق خاصة كفتحة الشرج في الحلم، قد يحمل هذا معاني تتعلّق بالنسل والعائلة. بمعنى آخر، قد يوحي هذا بأن الحالم سيشهد تطورات إيجابية في حياته الأسرية أو زيادة في عدد أفراد عائلته. أما رؤية الدود في فم الحالم تعد كعلامة على عدم الاستقرار النفسي أو العاطفي.</p>\r\n\r\n<h2>تفسير حلم خروج الدود من اليد اليمنى لابن سيرين في تأويلات ابن سيرين حول الأحلام،</h2>\r\n\r\n<p>يُعتبر ظهور الدود من اليد اليمنى علامة مبشرة بالخير. يُشير إلى إمكانية الحصول على ثروة مادية كبيرة في المستقبل القريب، مما يؤدي إلى حياة أكثر رفاهية للشخص الذي يرى هذا الحلم. من جانب آخر، إذا رأى الشخص الدود يخرج من يده ويأكل من جسده، قد يدل ذلك على ولادة أبناء صالحين ومباركين في حياته. هذه رؤية تدعو الشخص للتفاؤل والاهتمام بتربية أبنائه تربية تقوم على المبادئ الدينية والأخلاق الحميدة. كما أن حلم الدود الذي يخرج بكثرة من اليد يعد بشارة بالتقدم والترقية في المستقبل القريب.</p>\r\n\r\n<p>تفسير رؤية الدود الأبيض يخرج من اليد للمتزوجة في حالة ظهور دود أبيض كثير يتدفق من اليد، قد يعني أن المرأة تسعى للابتعاد عن الأخطاء أو الممارسات غير المرغوب فيها في حياتها، مع التطلع نحو بداية جديدة أكثر إيجابية. أما القضاء على الديدان قبل انتشارها في الجسد في الحلم، فيمكن أن يوحي بأن الشخص قد يواجه موقفاً صعباً أو مرضاً محتملاً يستطيع التغلب عليه قبل أن يتطور إلى أزمة أكبر. في تفسير آخر، إذا كان الدود يخرج بكميات كبيرة وينتشر دون إثارة أي إحساس لدى الرائي، فقد يعبر عن وجود أشخاص في حياة الحالم يظهرون وداً ولكنهم لا يتمنون له الخير. إذا رأت الشخصية في الحلم أن هناك سائل يتدفق من يدها بعد إزالة الديدان، فقد يشير هذا إلى بعض التوترات أو عدم الرضا في العلاقة الزوجية، مما يحتم على الشخص معالجتها. النوم في مكان ينتشر فيه الدود الأبيض يمكن أن يرمز إلى قرب حدوث تغيرات جذرية وإيجابية ستؤثر في حياة الرائية بشكل كامل، تحمل معها الأمل والتجديد. وأخيراً، عندما ينتشر الدود على جسم الزوج ضمن الحلم ويساعد الاثنان بعضهما البعض في التخلص منه، فهذا قد يدل على تقاسم الخيرات والبركات التي ستعود بالنفع على العلاقة الزوجية، معززاً الوحدة والترابط بينهما.<br />\r\n<br />\r\n<br />\r\n&nbsp;</p>\r\n\r\n<p>&nbsp;</p>', 5, '2024-06-01 12:22:02'),
(6, 1, 1, 'مقال جديد', '<p>رؤية الدود يخرج من إصبع اليد في الحلم تثير مشاعر عدم الراحة والقلق. يمكن أن تشير هذه الرؤيا إلى وجود مشكلات أو استياء خفي يؤرق الشخص ويضغط على نفسيته، مما يحتم عليه مواجهة هذه الصعوبات. في بعض الحالات، ترمز هذه الرؤية إلى الرغبة في التخلص من عادات أو أفكار ضارة تؤثر سلبًا على حياة الفرد، وتحث على التغيير نحو الأفضل والتحلي بالتفاؤل والإيجابية لضمان تحقيق توازن نفسي وصحي أفضل. يعتقد بعض المفسرين أن خروج الدود من اليد اليمنى يحمل بشارة بالتخلص من المتاعب والأحزان قريبًا وبلوغ الأهداف المنشودة. بينما قد يعتبر خروجه من اليد اليسرى تحذيرًا يدعو للانتباه إلى الهموم والمشكلات المحتملة</p>\r\n\r\n<h2>تفسير رؤية الدود يخرج من الجسد في المنام خروج الدود من الجسم في الأحلام</h2>\r\n\r\n<p>يعد كإشارة إلى التحديات والأزمات النفسية التي يمكن أن يواجهها الإنسان. فإذا حلم شخص أن الدود يمر من جسده، فهذا يمكن أن يُعبّر عن الضغوط والمشاكل العاطفية أو النفسية التي يعاني منها. وعندما يخرج الدود من مناطق خاصة كفتحة الشرج في الحلم، قد يحمل هذا معاني تتعلّق بالنسل والعائلة. بمعنى آخر، قد يوحي هذا بأن الحالم سيشهد تطورات إيجابية في حياته الأسرية أو زيادة في عدد أفراد عائلته. أما رؤية الدود في فم الحالم تعد كعلامة على عدم الاستقرار النفسي أو العاطفي.</p>\r\n\r\n<h2>تفسير حلم خروج الدود من اليد اليمنى لابن سيرين هانى درويش في تأويلات ابن سيرين حول الأحلام،</h2>\r\n\r\n<p>يُعتبر ظهور الدود من اليد اليمنى علامة مبشرة بالخير. يُشير إلى إمكانية الحصول على ثروة مادية كبيرة في المستقبل القريب، مما يؤدي إلى حياة أكثر رفاهية للشخص الذي يرى هذا الحلم. من جانب آخر، إذا رأى الشخص الدود يخرج من يده ويأكل من جسده، قد يدل ذلك على ولادة أبناء صالحين ومباركين في حياته. هذه رؤية تدعو الشخص للتفاؤل والاهتمام بتربية أبنائه تربية تقوم على المبادئ الدينية والأخلاق الحميدة. كما أن حلم الدود الذي يخرج بكثرة من اليد يعد بشارة بالتقدم والترقية في المستقبل القريب.</p>\r\n\r\n<p>تفسير رؤية الدود الأبيض يخرج من اليد للمتزوجة في حالة ظهور دود أبيض كثير يتدفق من اليد، قد يعني أن المرأة تسعى للابتعاد عن الأخطاء أو الممارسات غير المرغوب فيها في حياتها، مع التطلع نحو بداية جديدة أكثر إيجابية. أما القضاء على الديدان قبل انتشارها في الجسد في الحلم، فيمكن أن يوحي بأن الشخص قد يواجه موقفاً صعباً أو مرضاً محتملاً يستطيع التغلب عليه قبل أن يتطور إلى أزمة أكبر. في تفسير آخر، إذا كان الدود يخرج بكميات كبيرة وينتشر دون إثارة أي إحساس لدى الرائي، فقد يعبر عن وجود أشخاص في حياة الحالم يظهرون وداً ولكنهم لا يتمنون له الخير. إذا رأت الشخصية في الحلم أن هناك سائل يتدفق من يدها بعد إزالة الديدان، فقد يشير هذا إلى بعض التوترات أو عدم الرضا في العلاقة الزوجية، مما يحتم على الشخص معالجتها. النوم في مكان ينتشر فيه الدود الأبيض يمكن أن يرمز إلى قرب حدوث تغيرات جذرية وإيجابية ستؤثر في حياة الرائية بشكل كامل، تحمل معها الأمل والتجديد. وأخيراً، عندما ينتشر الدود على جسم الزوج ضمن الحلم ويساعد الاثنان بعضهما البعض في التخلص منه، فهذا قد يدل على تقاسم الخيرات والبركات التي ستعود بالنفع على العلاقة الزوجية، معززاً الوحدة والترابط بينهما.<br />\r\n<br />\r\n<br />\r\n&nbsp;</p>\r\n\r\n<p>&nbsp;</p>', 6, '2024-06-23 12:28:40'),
(7, 1, 1, 'مقال جديد', '<p>رؤية الدود يخرج من إصبع اليد في الحلم تثير مشاعر عدم الراحة والقلق. يمكن أن تشير هذه الرؤيا إلى وجود مشكلات أو استياء خفي يؤرق الشخص ويضغط على نفسيته، مما يحتم عليه مواجهة هذه الصعوبات. في بعض الحالات، ترمز هذه الرؤية إلى الرغبة في التخلص من عادات أو أفكار ضارة تؤثر سلبًا على حياة الفرد، وتحث على التغيير نحو الأفضل والتحلي بالتفاؤل والإيجابية لضمان تحقيق توازن نفسي وصحي أفضل. يعتقد بعض المفسرين أن خروج الدود من اليد اليمنى يحمل بشارة الحلم وقت صلاة العشاء بالتخلص من المتاعب والأحزان قريبًا وبلوغ الأهداف المنشودة. بينما قد يعتبر خروجه من اليد اليسرى تحذيرًا يدعو للانتباه إلى الهموم والمشكلات المحتملة</p>\r\n\r\n<h2>تفسير رؤية الدود يخرج من الجسد في المنام خروج الدود من الجسم في الأحلام</h2>\r\n\r\n<p>يعد كإشارة إلى التحديات والأزمات النفسية التي يمكن أن يواجهها الإنسان. فإذا حلم شخص أن الدود يمر من جسده، فهذا يمكن أن يُعبّر عن الضغوط والمشاكل العاطفية أو النفسية التي يعاني منها. وعندما يخرج الدود من مناطق خاصة كفتحة الشرج في الحلم، قد يحمل هذا معاني تتعلّق بالنسل والعائلة. بمعنى آخر، قد يوحي هذا بأن الحالم سيشهد تطورات إيجابية في حياته الأسرية أو زيادة في عدد أفراد عائلته. أما رؤية الدود في فم الحالم تعد كعلامة على عدم الاستقرار النفسي أو العاطفي.</p>\r\n\r\n<h2>تفسير حلم خروج الدود من اليد اليمنى لابن سيرين هانى درويش في تأويلات ابن سيرين حول الأحلام،</h2>\r\n\r\n<p>يُعتبر ظهور الدود من اليد اليمنى علامة مبشرة بالخير. يُشير إلى إمكانية الحصول على ثروة مادية كبيرة في المستقبل القريب، مما يؤدي إلى حياة أكثر رفاهية للشخص الذي يرى هذا الحلم. من جانب آخر، إذا رأى الشخص الدود يخرج من يده ويأكل من جسده، قد يدل ذلك على ولادة أبناء صالحين ومباركين في حياته. هذه رؤية تدعو الشخص للتفاؤل والاهتمام بتربية أبنائه تربية تقوم على المبادئ الدينية والأخلاق الحميدة. كما أن حلم الدود الذي يخرج بكثرة من اليد يعد بشارة بالتقدم والترقية في المستقبل القريب.</p>\r\n\r\n<p>تفسير رؤية الدود الأبيض يخرج من اليد للمتزوجة في حالة ظهور دود أبيض كثير يتدفق من اليد، قد يعني أن المرأة تسعى للابتعاد عن الأخطاء أو الممارسات غير المرغوب فيها في حياتها، مع التطلع نحو بداية جديدة أكثر إيجابية. أما القضاء على الديدان قبل انتشارها في الجسد في الحلم، فيمكن أن يوحي بأن الشخص قد يواجه موقفاً صعباً أو مرضاً محتملاً يستطيع التغلب عليه قبل أن يتطور إلى أزمة أكبر. في تفسير آخر، إذا كان الدود يخرج بكميات كبيرة وينتشر دون إثارة أي إحساس لدى الرائي، فقد يعبر عن وجود أشخاص في حياة الحالم يظهرون وداً ولكنهم لا يتمنون له الخير. إذا رأت الشخصية في الحلم أن هناك سائل يتدفق من يدها بعد إزالة الديدان، فقد يشير هذا إلى بعض التوترات أو عدم الرضا في العلاقة الزوجية، مما يحتم على الشخص معالجتها. النوم في مكان ينتشر فيه الدود الأبيض يمكن أن يرمز إلى قرب حدوث تغيرات جذرية وإيجابية ستؤثر في حياة الرائية بشكل كامل، تحمل معها الأمل والتجديد. وأخيراً، عندما ينتشر الدود على جسم الزوج ضمن الحلم ويساعد الاثنان بعضهما البعض في التخلص منه، فهذا قد يدل على تقاسم الخيرات والبركات التي ستعود بالنفع على العلاقة الزوجية، معززاً الوحدة والترابط بينهما.<br />\r\n<br />\r\n<br />\r\n&nbsp;</p>\r\n\r\n<p>&nbsp;</p>', 7, '2024-07-01 12:29:51'),
(8, 1, 1, 'مقال جديد', '<p>رؤية الدود يخرج من إصبع اليد في الحلم تثير مشاعر عدم الراحة والقلق. يمكن أن تشير هذه الرؤيا إلى وجود مشكلات أو استياء خفي يؤرق الشخص ويضغط على نفسيته، مما يحتم عليه مواجهة هذه الصعوبات. في بعض الحالات، ترمز هذه الرؤية إلى الرغبة في التخلص من عادات أو أفكار ضارة تؤثر سلبًا على حياة الفرد، وتحث على التغيير نحو الأفضل والتحلي بالتفاؤل والإيجابية لضمان تحقيق توازن نفسي وصحي أفضل. يعتقد بعض المفسرين أن خروج الدود من اليد اليمنى يحمل بشارة الحلم وقت صلاة العشاء بالتخلص من المتاعب والأحزان قريبًا وبلوغ الأهداف المنشودة. بينما قد يعتبر خروجه من اليد اليسرى تحذيرًا يدعو للانتباه إلى الهموم والمشكلات المحتملة</p>\r\n\r\n<h2>تفسير رؤية الدود يخرج من الجسد في المنام خروج الدود من الجسم في الأحلام</h2>\r\n\r\n<p>يعد كإشارة إلى التحديات والأزمات النفسية التي يمكن أن يواجهها الإنسان. فإذا حلم شخص أن الدود يمر من جسده، فهذا يمكن أن يُعبّر عن الضغوط والمشاكل العاطفية أو النفسية التي يعاني منها. وعندما يخرج الدود من مناطق خاصة كفتحة الشرج في الحلم، قد يحمل هذا معاني تتعلّق بالنسل والعائلة. بمعنى آخر، قد يوحي هذا بأن الحالم سيشهد تطورات إيجابية في حياته الأسرية أو زيادة في عدد أفراد عائلته. أما رؤية الدود في فم الحالم تعد كعلامة على عدم الاستقرار النفسي أو العاطفي.</p>\r\n\r\n<h2>تفسير حلم خروج الدود من اليد اليمنى لابن سيرين هانى درويش في تأويلات ابن سيرين حول الأحلام،</h2>\r\n\r\n<p>يُعتبر ظهور الدود من اليد اليمنى علامة مبشرة بالخير. يُشير إلى إمكانية الحصول على ثروة مادية كبيرة في احلام اليقظة ، مما يؤدي إلى حياة أكثر رفاهية للشخص الذي يرى هذا الحلم. من جانب آخر، إذا رأى الشخص الدود يخرج من يده ويأكل من جسده، قد يدل ذلك على ولادة أبناء صالحين ومباركين في حياته. هذه رؤية تدعو الشخص للتفاؤل والاهتمام بتربية أبنائه تربية تقوم على المبادئ الدينية والأخلاق الحميدة. كما أن حلم الدود الذي يخرج بكثرة من اليد يعد بشارة بالتقدم والترقية في المستقبل القريب.</p>\r\n\r\n<p>تفسير رؤية الدود الأبيض يخرج من اليد للمتزوجة في حالة ظهور دود أبيض كثير يتدفق من اليد، قد يعني أن المرأة تسعى للابتعاد عن الأخطاء أو الممارسات غير المرغوب فيها في حياتها، مع التطلع نحو بداية جديدة أكثر إيجابية. أما القضاء على الديدان قبل انتشارها في الجسد في الحلم، فيمكن أن يوحي بأن الشخص قد يواجه موقفاً صعباً أو مرضاً محتملاً يستطيع التغلب عليه قبل أن يتطور إلى أزمة أكبر. في تفسير آخر، إذا كان الدود يخرج بكميات كبيرة وينتشر دون إثارة أي إحساس لدى الرائي، فقد يعبر عن وجود أشخاص في حياة الحالم يظهرون وداً ولكنهم لا يتمنون له الخير. إذا رأت الشخصية في الحلم أن هناك سائل يتدفق من يدها بعد إزالة الديدان، فقد يشير هذا إلى بعض التوترات أو عدم الرضا في العلاقة الزوجية، مما يحتم على الشخص معالجتها. النوم في مكان ينتشر فيه الدود الأبيض يمكن أن يرمز إلى قرب حدوث تغيرات جذرية وإيجابية ستؤثر في حياة الرائية بشكل كامل، تحمل معها الأمل والتجديد. وأخيراً، عندما ينتشر الدود على جسم الزوج ضمن الحلم ويساعد الاثنان بعضهما البعض في التخلص منه، فهذا قد يدل على تقاسم الخيرات والبركات التي ستعود بالنفع على العلاقة الزوجية، معززاً الوحدة والترابط بينهما.<br />\r\n<br />\r\n<br />\r\n&nbsp;</p>\r\n\r\n<p>&nbsp;</p>', 8, '2024-07-12 12:30:44'),
(9, 1, 1, 'مقال جديد', '<p>رؤية الدود يخرج من إصبع اليد في الحلم تثير مشاعر عدم الراحة والقلق. يمكن أن تشير هذه الرؤيا إلى وجود مشكلات أو استياء خفي يؤرق الشخص ويضغط على نفسيته، مما يحتم عليه مواجهة هذه الصعوبات. في بعض الحالات، ترمز هذه الرؤية إلى الرغبة في التخلص من عادات أو أفكار ضارة تؤثر سلبًا على حياة الفرد، وتحث على التغيير نحو الأفضل والتحلي بالتفاؤل والإيجابية لضمان تحقيق توازن نفسي وصحي أفضل. يعتقد بعض المفسرين أن خروج الدود من اليد اليمنى يحمل بشارة الحلم وقت صلاة العشاء بالتخلص من المتاعب والأحزان قريبًا وبلوغ الأهداف المنشودة. بينما قد يعتبر خروجه من اليد اليسرى تحذيرًا يدعو للانتباه إلى الهموم والمشكلات المحتملة</p>\r\n\r\n<h2>تفسير رؤية الدود يخرج من الجسد في المنام خروج الدود من الجسم في الأحلام</h2>\r\n\r\n<p>يعد كإشارة إلى التحديات والأزمات النفسية التي يمكن أن يواجهها الإنسان. فإذا حلم شخص أن الدود يمر من جسده، فهذا يمكن أن يُعبّر عن الضغوط والمشاكل العاطفية أو النفسية التي يعاني منها. وعندما يخرج الدود من مناطق خاصة كفتحة الشرج في الحلم، قد يحمل هذا معاني تتعلّق بالنسل والعائلة. بمعنى آخر، قد يوحي هذا بأن الحالم سيشهد تطورات إيجابية في حياته الأسرية أو زيادة في عدد أفراد عائلته. أما رؤية الدود في فم الحالم تعد كعلامة على عدم الاستقرار النفسي أو العاطفي.</p>\r\n\r\n<h2>تفسير حلم خروج الدود من اليد اليمنى لابن سيرين هانى درويش في تأويلات ابن سيرين حول الأحلام،</h2>\r\n\r\n<p>يُعتبر ظهور الدود من اليد اليمنى علامة مبشرة بالخير. يُشير إلى إمكانية الحصول على ثروة مادية كبيرة في احلام اليقظة ، مما يؤدي إلى حياة أكثر رفاهية للشخص الذي يرى هذا الحلم. من جانب آخر، إذا رأى الشخص الدود يخرج من يده ويأكل من جسده، قد يدل ذلك على ولادة أبناء صالحين ومباركين في حياته. هذه رؤية تدعو الشخص للتفاؤل والاهتمام بتربية أبنائه تربية تقوم على المبادئ الدينية والأخلاق الحميدة. كما أن حلم الدود الذي يخرج بكثرة من اليد يعد بشارة بالتقدم والترقية في المستقبل القريب.</p>\r\n\r\n<p>تفسير رؤية الدود الأبيض يخرج من اليد للمتزوجة في حالة ظهور دود أبيض كثير يتدفق من اليد، قد يعني أن المرأة تسعى للابتعاد عن الأخطاء أو الممارسات غير المرغوب فيها في حياتها، مع التطلع نحو بداية جديدة أكثر إيجابية. أما القضاء على الديدان قبل انتشارها في الجسد في الحلم، فيمكن أن يوحي بأن الشخص قد يواجه موقفاً صعباً أو مرضاً محتملاً يستطيع التغلب عليه قبل أن يتطور إلى أزمة أكبر. في تفسير آخر، إذا كان الدود يخرج بكميات كبيرة وينتشر دون إثارة أي إحساس لدى الرائي، فقد يعبر عن وجود أشخاص في حياة الحالم يظهرون وداً ولكنهم لا يتمنون له الخير. إذا رأت الشخصية في الحلم أن هناك سائل يتدفق من يدها بعد إزالة الديدان، فقد يشير هذا إلى بعض التوترات ، تحمل معها الأمل والتجديد. وأخيراً، عندما ينتشر الدود على جسم الزوج ضمن الحلم ويساعد الاثنان بعضهما البعض في التخلص منه، فهذا قد يدل على تقاسم الخيرات والبركات التي ستعود بالنفع على العلاقة الزوجية، معززاً الوحدة والترابط بينهما.</p>\r\n\r\n<p>يعد كإشارة إلى التحديات والأزمات النفسية التي يمكن أن يواجهها الإنسان. فإذا حلم شخص أن الدود يمر من جسده، فهذا يمكن أن يُعبّر عن الضغوط والمشاكل العاطفية أو النفسية التي يعاني منها. وعندما يخرج الدود من مناطق خاصة كفتحة الشرج في الحلم، قد يحمل هذا معاني تتعلّق بالنسل والعائلة. بمعنى آخر، قد يوحي هذا بأن الحالم سيشهد تطورات إيجابية في حياته الأسرية أو زيادة في عدد أفراد عائلته. أما رؤية الدود في فم الحالم تعد كعلامة على عدم الاستقرار النفسي أو العاطفي.<br />\r\n<br />\r\n&nbsp;</p>\r\n\r\n<p>&nbsp;</p>', 9, '2024-07-15 12:56:33'),
(10, 1, 1, 'مقال جديد', '<p>تغير المقال بالكامل<br />\r\n&nbsp;</p>\r\n\r\n<p>&nbsp;</p>', 10, '2024-07-20 12:57:33'),
(11, 1, 1, 'مقال جديد', '<p>يعد كإشارة إلى التحديات والأزمات النفسية التي يمكن أن يواجهها الإنسان. فإذا حلم شخص أن الدود يمر من جسده، فهذا يمكن أن يُعبّر عن الضغوط والمشاكل العاطفية أو النفسية التي يعاني منها. وعندما يخرج الدود من مناطق خاصة كفتحة الشرج في الحلم، قد يحمل هذا معاني تتعلّق بالنسل والعائلة. بمعنى آخر، قد يوحي هذا بأن الحالم سيشهد تطورات إيجابية في حياته الأسرية أو زيادة في عدد أفراد عائلته. أما رؤية الدود في فم الحالم تعد كعلامة على عدم الاستقرار النفسي أو العاطفي.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>', 11, '2024-07-22 13:01:40'),
(12, 1, 1, 'مقال جديد', '<p>يعد كإشارة إلى التحديات والأزمات النفسية التي يمكن أن يواجهها الإنسان. فإذا حلم شخص أن الدود يمر من جسده، فهذا يمكن أن يُعبّر عن الضغوط والمشاكل العاطفية أو النفسية التي يعاني منها. وعندما يخرج الدود من مناطق خاصة كفتحة الشرج في الحلم، قد يحمل هذا معاني تتعلّق بالنسل والعائلة. بمعنى آخر، قد يوحي هذا بأن الحالم سيشهد تطورات إيجابية في حياته الأسرية أو زيادة في عدد أفراد عائلته. أما رؤية الدود في فم الحالم تعد كعلامة على عدم الاستقرار النفسي أو العاطفي.</p>\r\n\r\n<p>تُشير رؤية خروج الدود الأبيض من اليد في الأحلام للمرأة المتزوجة إلى مجموعة من الرسائل والدلالات المختلفة حسب سياق الحلم. في حالة ظهور دود أبيض كثير يتدفق من اليد، قد يعني هذا أن الشخص يسعى للابتعاد عن الأخطاء أو الممارسات غير المرغوب فيها في حياته، مع التطلع نحو بداية جديدة أكثر إيجابية وتركيزاً على الالتزام الروحاني.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>', 12, '2024-07-23 13:02:07'),
(13, 1, 1, 'مقال جديد', '<p>يعد كإشارة إلى التحديات والأزمات النفسية التي يمكن أن يواجهها الإنسان. فإذا حلم شخص أن الدود يمر من جسده، فهذا يمكن أن يُعبّر عن الضغوط والمشاكل العاطفية أو النفسية التي يعاني منها. وعندما يخرج الدود من مناطق خاصة كفتحة الشرج في الحلم، قد يحمل هذا معاني تتعلّق بالنسل والعائلة. بمعنى آخر، قد يوحي هذا بأن الحالم سيشهد تطورات إيجابية في حياته الأسرية أو زيادة في عدد أفراد عائلته. أما رؤية الدود في فم الحالم تعد كعلامة على عدم الاستقرار النفسي أو العاطفي.</p>\r\n\r\n<p>تُشير رؤية خروج الدود الأبيض من اليد في الأحلام للمرأة المتزوجة إلى مجموعة من الرسائل والدلالات المختلفة حسب سياق الحلم. في حالة ظهور دود أبيض كثير يتدفق من اليد، قد يعني هذا أن الشخص يسعى للابتعاد عن الأخطاء أو الممارسات غير المرغوب فيها في حياته، مع التطلع نحو بداية جديدة أكثر إيجابية وتركيزاً على الالتزام الروحاني.</p>\r\n\r\n<p>لابد من متابعة التعديلات التى قد تحدث</p>\r\n\r\n<p>&nbsp;</p>', 13, '2024-07-23 13:59:48');

-- --------------------------------------------------------

--
-- Table structure for table `blog_tags`
--

CREATE TABLE `blog_tags` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `old_id` int(11) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `old_count` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blog_tags_post`
--

CREATE TABLE `blog_tags_post` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tag_id` bigint(20) UNSIGNED NOT NULL,
  `blog_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blog_tags_translations`
--

CREATE TABLE `blog_tags_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tag_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trim` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blog_translations`
--

CREATE TABLE `blog_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `blog_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des_text` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug_count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_translations`
--

INSERT INTO `blog_translations` (`id`, `blog_id`, `locale`, `slug`, `name`, `des`, `des_text`, `g_title`, `g_des`, `youtube_title`, `slug_count`) VALUES
(1, 1, 'ar', 'مقال-جديد', 'مقال جديد', '<p>يعد كإشارة إلى التحديات والأزمات النفسية التي يمكن أن يواجهها الإنسان. فإذا حلم شخص أن الدود يمر من جسده، فهذا يمكن أن يُعبّر عن الضغوط والمشاكل العاطفية أو النفسية التي يعاني منها. وعندما يخرج الدود من مناطق خاصة كفتحة الشرج في الحلم، قد يحمل هذا معاني تتعلّق بالنسل والعائلة. بمعنى آخر، قد يوحي هذا بأن الحالم سيشهد تطورات إيجابية في حياته الأسرية أو زيادة في عدد أفراد عائلته. أما رؤية الدود في فم الحالم تعد كعلامة على عدم الاستقرار النفسي أو العاطفي.</p>\r\n\r\n<p>في بعض التفسيرات، ربما تدل هذه الرؤيا على انتصار الرائي على المؤامرات أو الخداع الذي قد يواجهه من آخرين حوله. هذه الانتصارات قد لا تكون ملموسة فحسب، بل تعزز أيضًا الثقة بالنفس وتُعد الشخص لتجاوز محن أخرى قد تعترض طريقه.</p>\r\n\r\n<p>&nbsp;</p>', 'يعد كإشارة إلى التحديات والأزمات النفسية التي يمكن أن يواجهها الإنسان. فإذا حلم شخص أن الدود يمر من جسده، فهذا يمكن أن يُعبّر عن الضغوط والمشاكل العاطفية أو النفسية التي يعاني منها. وعندما يخرج الدود من مناطق خاصة كفتحة الشرج في الحلم، قد يحمل هذا معاني تتعلّق بالنسل والعائلة. بمعنى آخر، قد يوحي هذا بأن الحالم سيشهد تطورات إيجابية في حياته الأسرية أو زيادة في عدد أفراد عائلته. أما رؤية الدود في فم الحالم تعد كعلامة على عدم الاستقرار النفسي أو العاطفي. في بعض التفسيرات، ربما تدل هذه الرؤيا على انتصار الرائي على المؤامرات أو الخداع الذي قد يواجهه من آخرين حوله. هذه الانتصارات قد لا تكون ملموسة فحسب، بل تعزز أيضًا الثقة بالنفس وتُعد الشخص لتجاوز محن أخرى قد تعترض طريقه.', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `config_def_photos`
--

CREATE TABLE `config_def_photos` (
  `id` int(10) UNSIGNED NOT NULL,
  `cat_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postion` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_def_photos`
--

INSERT INTO `config_def_photos` (`id`, `cat_id`, `photo`, `photo_thum_1`, `photo_thum_2`, `postion`, `created_at`, `updated_at`) VALUES
(4, 'blog', 'images/def-photo/blog-lltlovlEF3.webp', 'images/def-photo/blog-AfI3kWRbfw.webp', NULL, 4, '2023-08-16 09:18:40', '2024-03-30 18:57:31'),
(12, 'err_404', 'images/def-photo/err-404-GyYn77ncLv.webp', NULL, NULL, 10, '2024-01-25 09:48:47', '2024-01-28 16:32:58'),
(15, 'logo', 'images/def-photo/logo-CdlZqBIJe7.webp', 'images/def-photo/logo-amPNaAteuf.webp', NULL, 0, '2024-02-21 14:53:44', '2024-03-30 18:57:16'),
(16, 'categories', 'images/def-photo/categories-6kv3GqDjVd.webp', 'images/def-photo/categories-KkqVu4CzPY.webp', NULL, 0, '2024-03-30 17:19:40', '2024-03-30 17:47:03');

-- --------------------------------------------------------

--
-- Table structure for table `config_file_manager`
--

CREATE TABLE `config_file_manager` (
  `id` int(10) UNSIGNED NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `config_menu`
--

CREATE TABLE `config_menu` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sel_routs` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `roleView` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `postion` int(11) NOT NULL DEFAULT 30
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_menu`
--

INSERT INTO `config_menu` (`id`, `parent_id`, `type`, `sel_routs`, `url`, `name`, `icon`, `roleView`, `is_active`, `postion`) VALUES
(1, NULL, 'Many', 'admin.config', NULL, 'admin.app_menu_setting', 'fas fa-cogs', 'config_view', 1, 80),
(2, 1, NULL, 'web.index', 'admin.config.web.index', 'admin/config/webConfig.app_menu', 'fas fa-cog', 'config_website', 1, 30),
(3, 1, NULL, 'Meta.index|Meta.create|Meta.edit|Meta.config', 'admin.config.Meta.index', 'admin/configMeta.app_menu', 'fab fa-html5', 'config_meta_view', 1, 30),
(4, 1, NULL, 'defPhoto.index|defPhoto.create|defPhoto.edit|defPhoto.config|defPhoto.sortDefPhotoList', 'admin.config.defPhoto.index', 'admin/config/upFilter.app_menu_def_photo', 'fas fa-image', 'config_defPhoto_view', 1, 30),
(5, 1, NULL, 'upFilter.index|upFilter.create|upFilter.edit|upFilter.config|upFilter.size.create|upFilter.size.edit', 'admin.config.upFilter.index', 'admin/config/upFilter.app_menu', 'fas fa-filter', 'config_upFilter_view', 1, 30),
(6, 1, NULL, 'WebPrivacy.index|WebPrivacy.create|WebPrivacy.edit|WebPrivacy.config', 'admin.config.WebPrivacy.index', 'admin/configPrivacy.app_menu', 'fas fa-file-alt', 'config_web_privacy', 1, 30),
(7, NULL, 'Many', 'admin.users', NULL, 'admin/config/roles.menu_roles', 'fas fa-unlock-alt', 'users_view', 1, 99),
(8, 7, NULL, 'UserList.index', 'admin.users.UserList.index', 'admin/config/roles.menu_roles_users', 'fas fa-users', 'users_view', 1, 30),
(9, 7, NULL, 'roles.index', 'admin.users.roles.index', 'admin/config/roles.menu_roles_role', 'fas fa-traffic-light', 'roles_view', 1, 30),
(10, 7, NULL, 'permissions.index', 'admin.users.permissions.index', 'admin/config/roles.menu_roles_permissions', 'fas fa-user-shield', 'roles_view', 1, 30),
(11, NULL, 'One', 'admin.adminlang', 'admin.adminlang.index', 'admin.app_menu_lang_admin', 'fas fa-language', 'adminlang_view', 1, 100),
(12, NULL, 'One', 'admin.weblang', 'admin.weblang.index', 'admin.app_menu_lang_web', 'fas fa-language', 'weblang_view', 1, 101),
(13, NULL, 'Many', 'admin.Blog', NULL, 'admin/blogPost.app_menu', 'fab fa-blogger', 'Blog_view', 1, 30),
(14, 13, NULL, 'BlogCategory.index|BlogCategory.create|BlogCategory.edit|BlogCategory.config|BlogCategory.index_Main|BlogCategory.SubCategory|BlogCategory.CatSort|BlogCategory.editEn|BlogCategory.editAr|BlogCategory.create_ar|BlogCategory.create_en|BlogCategory.filter|', 'admin.Blog.BlogCategory.index', 'admin/blogPost.app_menu_category', 'fas fa-sitemap', 'Blog_view', 1, 30),
(15, 13, NULL, 'BlogPost.create', 'admin.Blog.BlogPost.create', 'admin/blogPost.app_menu_add_blog', 'fas fa-plus-circle', 'Blog_view', 1, 30),
(16, 13, NULL, 'BlogPost.index|BlogPost.filter|BlogPost.edit|BlogPost.editEn|BlogPost.editAr', 'admin.Blog.BlogPost.index', 'admin/blogPost.app_menu_blog', 'fas fa-rss', 'Blog_view', 1, 30),
(17, 13, NULL, 'BlogPost.index_draft|BlogPost.filter_draft', 'admin.Blog.BlogPost.index_draft', 'admin/blogPost.app_menu_blog_draft', 'fas fa-pencil-ruler', 'Blog_view', 1, 30),
(18, 13, NULL, 'BlogTags.index|BlogTags.edit|BlogTags.create|BlogTags.config', 'admin.Blog.BlogTags.index', 'admin/blogPost.app_menu_tags', 'fas fa-hashtag', 'Blog_view', 1, 30),
(19, NULL, 'Many', 'admin.Pages', NULL, 'admin/pages.app_menu', 'fab fa-html5', 'Pages_view', 1, 30),
(20, 19, NULL, 'PageCategory.index|PageCategory.create|PageCategory.edit|PageCategory.config|PageCategory.index_Main|PageCategory.SubCategory|PageCategory.CatSort|PageCategory.editEn|PageCategory.editAr|PageCategory.create_ar|PageCategory.create_en|PageCategory.filter|', 'admin.Pages.PageCategory.index', 'admin/pages.app_menu_category', 'fas fa-sitemap', 'Pages_view', 1, 30),
(21, 19, NULL, 'PageList.index|PageList.create|PageList.edit|PageList.config|PageList.index_Main|PageList.SubCategory|PageList.CatSort|PageList.editEn|PageList.editAr|PageList.create_ar|PageList.create_en|PageList.filter|', 'admin.Pages.PageList.index', 'admin/pages.app_menu_page', 'fas fa-file-code', 'Pages_view', 1, 30),
(22, 19, NULL, 'PageList.createNew', 'admin.Pages.PageList.create', 'admin/pages.app_menu_add_page', 'fas fa-plus-circle', 'Pages_view', 1, 30),
(23, NULL, 'One', 'admin.fileManager', 'admin.fileManager.index', 'admin/fileManager.app_menu', 'fas fa-images', 'FileManager_view', 1, 150);

-- --------------------------------------------------------

--
-- Table structure for table `config_meta_tags`
--

CREATE TABLE `config_meta_tags` (
  `id` int(10) UNSIGNED NOT NULL,
  `cat_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_meta_tags`
--

INSERT INTO `config_meta_tags` (`id`, `cat_id`, `photo`, `photo_thum_1`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'home', NULL, NULL, '2023-08-16 09:18:40', '2023-08-16 09:18:40', NULL),
(2, 'categories', NULL, NULL, '2023-08-16 11:16:16', '2024-03-28 21:54:22', NULL),
(3, 'AboutUs', NULL, NULL, '2023-08-16 11:30:42', '2024-03-28 22:41:19', NULL),
(4, 'Review', NULL, NULL, '2023-08-16 11:32:36', '2024-03-28 22:41:45', NULL),
(7, 'err_404', NULL, NULL, '2024-01-25 13:35:18', '2024-01-25 13:35:18', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `config_meta_tag_translations`
--

CREATE TABLE `config_meta_tag_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `meta_tag_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_meta_tag_translations`
--

INSERT INTO `config_meta_tag_translations` (`id`, `meta_tag_id`, `locale`, `name`, `des`, `g_title`, `g_des`) VALUES
(1, 1, 'ar', NULL, NULL, 'مقالات', 'موقع مقالات'),
(3, 2, 'ar', NULL, NULL, 'الاقسام', 'الاقسام'),
(5, 3, 'ar', NULL, NULL, 'من نحن', 'من نحن'),
(7, 4, 'ar', NULL, NULL, 'معايير تدقيق المحتوى', 'معايير تدقيق المحتوى'),
(13, 7, 'ar', NULL, NULL, 'عذرًا !! الصفحة التي تبحث عنها غير موجودة.', 'عذرًا !! الصفحة التي تبحث عنها غير موجودة.');

-- --------------------------------------------------------

--
-- Table structure for table `config_settings`
--

CREATE TABLE `config_settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `web_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `web_status` int(11) NOT NULL DEFAULT 1,
  `switch_lang` int(11) NOT NULL DEFAULT 1,
  `users_login` int(11) NOT NULL DEFAULT 1,
  `serach` int(11) NOT NULL DEFAULT 1,
  `serach_type` int(11) NOT NULL DEFAULT 1,
  `wish_list` int(11) NOT NULL DEFAULT 1,
  `phone_num` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_num` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_call` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_send` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `def_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_api` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram_send` int(11) DEFAULT NULL,
  `telegram_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram_group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `page_about` int(11) NOT NULL DEFAULT 1,
  `page_warranty` int(11) NOT NULL DEFAULT 1,
  `page_shipping` int(11) NOT NULL DEFAULT 1,
  `pro_sale_lable` int(11) NOT NULL DEFAULT 1,
  `pro_quick_view` int(11) NOT NULL DEFAULT 1,
  `pro_quick_shop` int(11) NOT NULL DEFAULT 1,
  `pro_warranty_tab` int(11) NOT NULL DEFAULT 1,
  `pro_shipping_tab` int(11) NOT NULL DEFAULT 1,
  `pro_social_share` int(11) NOT NULL DEFAULT 1,
  `pro_free_shipping` int(11) NOT NULL DEFAULT 1,
  `pro_main_city_id` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`pro_main_city_id`)),
  `pro_main_city_rate` int(11) DEFAULT NULL,
  `pro_main_city_discount` int(11) DEFAULT NULL,
  `pro_all_city_rate` int(11) DEFAULT NULL,
  `pro_all_city_discount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_settings`
--

INSERT INTO `config_settings` (`id`, `web_url`, `web_status`, `switch_lang`, `users_login`, `serach`, `serach_type`, `wish_list`, `phone_num`, `whatsapp_num`, `phone_call`, `whatsapp_send`, `email`, `def_url`, `facebook`, `youtube`, `twitter`, `instagram`, `linkedin`, `google_api`, `telegram_send`, `telegram_key`, `telegram_phone`, `telegram_group`, `page_about`, `page_warranty`, `page_shipping`, `pro_sale_lable`, `pro_quick_view`, `pro_quick_shop`, `pro_warranty_tab`, `pro_shipping_tab`, `pro_social_share`, `pro_free_shipping`, `pro_main_city_id`, `pro_main_city_rate`, `pro_main_city_discount`, `pro_all_city_rate`, `pro_all_city_discount`) VALUES
(1, '#', 0, 0, 1, 1, 1, 1, '0100-34-00002', '0100-34-00002', '01003400002', '201003400002', 'info@islamic-dreams-interpretation.com', 'https://islamic-dreams-interpretation.com', 'https://www.facebook.com/', 'https://www.youtube.com', 'https://www.twitter.com/', 'https://www.Instagram.com/', 'https://www.linkedin.com/', NULL, 0, '6313317483:AAEooBTEFel1ej1uaDpXcZzCrbX_ID3aYEw', '-4091280818', '200119925', 1, 2, 3, 1, 1, 1, 1, 1, 1, 1, '[\"1\",\"2\",\"3\"]', 200, 7000, 400, 10000);

-- --------------------------------------------------------

--
-- Table structure for table `config_setting_translations`
--

CREATE TABLE `config_setting_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `setting_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `closed_mass` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_setting_translations`
--

INSERT INTO `config_setting_translations` (`id`, `setting_id`, `locale`, `name`, `closed_mass`) VALUES
(1, 1, 'ar', 'موقع تفسير الاحلام لابن سيرين', 'عذرا جارى اجراء بعض التحديثات \r\nسنعود قريبا'),
(2, 1, 'en', 'Cotton Shop', 'Sorry, some updates are being made\r\nWe will be back soon');

-- --------------------------------------------------------

--
-- Table structure for table `config_upload_filters`
--

CREATE TABLE `config_upload_filters` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(11) NOT NULL DEFAULT 1,
  `convert_state` int(11) NOT NULL DEFAULT 1,
  `quality_val` int(11) NOT NULL DEFAULT 85,
  `new_w` int(11) NOT NULL,
  `new_h` int(11) NOT NULL,
  `canvas_back` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#ffffff',
  `greyscale` int(11) NOT NULL DEFAULT 0,
  `flip_state` int(11) NOT NULL DEFAULT 0,
  `flip_v` int(11) NOT NULL DEFAULT 0,
  `blur` int(11) NOT NULL DEFAULT 0,
  `blur_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `pixelate` int(11) NOT NULL DEFAULT 0,
  `pixelate_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '5',
  `text_state` int(11) NOT NULL DEFAULT 0,
  `text_print` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_opacity` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text_position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `watermark_state` int(11) NOT NULL DEFAULT 0,
  `watermark_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `watermark_position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `notes_ar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_upload_filters`
--

INSERT INTO `config_upload_filters` (`id`, `name`, `type`, `convert_state`, `quality_val`, `new_w`, `new_h`, `canvas_back`, `greyscale`, `flip_state`, `flip_v`, `blur`, `blur_size`, `pixelate`, `pixelate_size`, `text_state`, `text_print`, `font_size`, `font_path`, `font_color`, `font_opacity`, `text_position`, `watermark_state`, `watermark_img`, `watermark_position`, `state`, `notes_ar`, `notes_en`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'NoEdit', 1, 1, 85, 100, 100, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, '2023-10-15 07:42:57', '2023-10-15 07:42:57', NULL),
(2, 'DefPhoto', 4, 1, 85, 800, 420, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, '2023-10-15 07:42:57', '2023-10-15 07:42:57', NULL),
(3, 'FavIcon', 4, 1, 85, 40, 40, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, '2023-10-15 07:42:57', '2023-10-15 07:42:57', NULL),
(4, 'المجموعات', 4, 1, 85, 450, 280, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 'برجاء مراعاة ان تكون الصورة مربعة اقل عرض 500 اقل ارتفاع 500 سيتم اعادة ضبط ابعاد الصورة على خلفيه بيضاء فى حالة عدم تساوى النسب', NULL, '2023-10-15 07:42:57', '2024-03-30 17:09:51', NULL),
(7, 'المقالات', 4, 1, 85, 800, 420, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 'برجاء مراعاة ان تكون الصورة مستطيلة  اقل عرض 800 اقل ارتفاع 420 سيتم قص الصورة وفقا للابعاد المحددة', NULL, '2024-01-22 17:51:06', '2024-01-23 14:07:22', NULL),
(8, 'المقالات المزيد من الصور', 4, 1, 85, 1024, 768, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 'برجاء مراعاة ان تكون الصورة مستطيلة  اقل عرض  1024 سيتم ضبط ابعاد الصور وفقا لحجم العرض', NULL, '2024-01-22 19:39:31', '2024-01-23 14:06:23', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `config_upload_filter_sizes`
--

CREATE TABLE `config_upload_filter_sizes` (
  `id` int(10) UNSIGNED NOT NULL,
  `filter_id` int(10) UNSIGNED NOT NULL,
  `type` int(11) NOT NULL DEFAULT 1,
  `new_w` int(11) NOT NULL,
  `new_h` int(11) NOT NULL,
  `canvas_back` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `get_more_option` int(11) NOT NULL DEFAULT 0,
  `get_add_text` int(11) NOT NULL DEFAULT 0,
  `get_watermark` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_upload_filter_sizes`
--

INSERT INTO `config_upload_filter_sizes` (`id`, `filter_id`, `type`, `new_w`, `new_h`, `canvas_back`, `get_more_option`, `get_add_text`, `get_watermark`) VALUES
(1, 2, 4, 500, 335, NULL, 0, 0, 0),
(2, 4, 4, 450, 280, '#FFFFFF', 0, 0, 0),
(6, 7, 4, 500, 300, '#FFFFFF', 0, 0, 0),
(7, 8, 4, 600, 450, '#FFFFFF', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `config_web_privacies`
--

CREATE TABLE `config_web_privacies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postion` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_web_privacies`
--

INSERT INTO `config_web_privacies` (`id`, `name`, `postion`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 'شروط وسياسة الخصوصية', 2, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(3, 'جمع المعلومات واستخدامها', 3, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(4, 'أنواع البيانات المجمعة', 4, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(5, 'بيانات الاستخدام', 5, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(6, 'تتبع و ملفات تعريف الارتباط', 6, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(7, 'استخدام البيانات', 7, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(8, 'نقل البيانات', 8, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(9, 'الكشف عن البيانات', 9, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(10, 'أمن البيانات', 10, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(11, 'مقدمي الخدمة', 11, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(12, 'تحليلات', 12, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(13, 'روابط لمواقع أخرى', 13, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(14, 'خصوصية الأطفال', 14, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(15, 'تغييرات سياسة الخصوصية', 15, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL),
(16, 'اتصل بنا', 16, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `config_web_privacy_translations`
--

CREATE TABLE `config_web_privacy_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `privacy_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `h1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `h2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lists` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_web_privacy_translations`
--

INSERT INTO `config_web_privacy_translations` (`id`, `privacy_id`, `locale`, `h1`, `h2`, `des`, `lists`) VALUES
(3, 2, 'ar', 'شروط وسياسة الخصوصية', '', 'تقوم شركة [CompanyName] (\"نحن\" أو \"نحن\" أو \"موقعنا\") بتشغيل [WebSiteName]  (\"الموقع الالكترونى\").\r\nتُعرفك هذه الصفحة بسياساتنا المتعلقة بجمع البيانات الشخصية واستخدامها والكشف عنها عند استخدامك للخدمة والأختيارات المرتبطة بهذه البيانات. \r\nسياسة الخصوصية لشركة [CompanyName]\r\nنستخدم بياناتك لتوفير الخدمة وتحسينها. باستخدام الخدمة، فإنك توافق على جمع واستخدام المعلومات وفقًا لهذه السياسة. ما لم يتم تحديد خلاف ذلك في سياسة الخصوصية، فإن المصطلحات المستخدمة في سياسة الخصوصية لها نفس المعاني كما في الشروط والأحكام الخاصة بنا، والتي يمكن الوصول إليها من [WebSiteName]', ''),
(4, 2, 'en', 'Privacy Policy', '', ' [CompanyName] (\"us\", \"we\", or \"our\") operates the [WebSiteName] website (the \"Service\").\r\nThis page informs you of our policies regarding the collection, use, and disclosure of personal data when you use our Service and the choices you have associated with that data. Our Privacy Policy for [CompanyName]\r\nWe use your data to provide and improve the Service. By using the Service, you agree to the collection and use of information in accordance with this policy. Unless otherwise defined in this Privacy Policy, terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, accessible from  [WebSiteName]', ''),
(5, 3, 'ar', 'جمع المعلومات واستخدامها', '', 'نقوم بتجميع أنواع مختلفة من المعلومات لأغراض متنوعة لتوفير وتحسين خدماتنا لك.', ''),
(6, 3, 'en', 'Information Collection And Use', '', 'We collect several different types of information for various purposes to provide and improve our Service to you.', ''),
(7, 4, 'ar', 'أنواع البيانات المجمعة', 'بيانات شخصية', 'أثناء استخدام خدماتنا ، قد نطلب منك تزويدنا بمعلومات تعريف شخصية معينة يمكن استخدامها للاتصال أو التعرف عليك (&quot;البيانات الشخصية&quot;). قد تتضمن معلومات \r\nالتعريف الشخصية ، على سبيل المثال لا الحصر ، ما يلي:', 'عنوان بريد الكتروني\r\nالاسم الأول واسم العائلة\r\nرقم الهاتف\r\nالعنوان ، الولاية ، المقاطعة ، الرمز البريدي / المدينة ، المدينة\r\nملفات تعريف الارتباط وبيانات الاستخدام'),
(8, 4, 'en', 'Types of Data Collected', 'Personal Data', 'While using our Service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you (&quot;Personal Data&quot;). Personally identifiable information may include, but is not limited to :', 'Email address\r\nFirst name and last name\r\nPhone number\r\nAddress, State, Province, ZIP/Postal code, City\r\nCookies and Usage Data'),
(9, 5, 'ar', 'بيانات الاستخدام', '', 'يجوز لنا أيضًا جمع المعلومات حول كيفية الوصول إلى الخدمة واستخدامها (&quot;بيانات الاستخدام&quot;). قد تتضمن بيانات الاستخدام هذه معلومات مثل عنوان بروتوكول الإنترنت الخاص بجهاز الكمبيوتر (مثل عنوان IP) ، ونوع المتصفح، وإصدار المتصفح، وصفحات الخدمة التي تزورها، ووقت وتاريخ زيارتك، والوقت الذي يقضيه في تلك الصفحات، ومعرفات الجهاز وغيرها من البيانات التشخيصية.', ''),
(10, 5, 'en', 'Usage Data', '', 'We may also collect information how the Service is accessed and used (&quot;Usage Data&quot;). This Usage Data may include information such as your computer\'s Internet Protocol address (e.g. IP address), browser type, browser version, the pages of our Service that you visit, the time and date of your visit, the time spent on those pages, unique device identifiers and other diagnostic data.', ''),
(11, 6, 'ar', 'تتبع و ملفات تعريف الارتباط', '', 'نحن نستخدم ملفات تعريف الارتباط وتقنيات التتبع المماثلة لتتبع النشاط على الخدمة لدينا مع الاحتفاظ بمعلومات معينة.\r\nملفات تعريف الارتباط عبارة عن ملفات تحتوي على كمية صغيرة من البيانات التي قد تتضمن معرفًا فريدًا مجهول الهوية. يتم إرسال ملفات تعريف الارتباط إلى متصفحك من موقع الويب وتخزينها على جهازك. تقنيات التتبع المستخدمة هي منارات وعلامات ونصوص لجمع المعلومات وتتبعها ولتحسين خدمتنا وتحليلها.\r\nيمكنك إرشاد المتصفح الخاص بك لرفض جميع ملفات تعريف الارتباط أو للإشارة إلى إرسال ملف تعريف الارتباط. ومع ذلك، إذا كنت لا تقبل ملفات تعريف الارتباط، فقد لا تتمكن من استخدام بعض أجزاء من خدمتنا.\r\n\r\nأمثلة على ملفات تعريف الارتباط التي نستخدمها:', 'نحن نستخدم ملفات تعريف الارتباط الخاصة بالجلسات لتشغيل الخدمة الخاصة بنا.\r\nنحن نستخدم ملفات تعريف الارتباط التفضيلية لتذكر تفضيلاتك والإعدادات المختلفة.\r\nنحن نستخدم ملفات تعريف الارتباط للأمان لأغراض أمنية.'),
(12, 6, 'en', 'Tracking &amp; Cookies Data', '', 'We use cookies and similar tracking technologies to track the activity on our Service and hold certain information.\r\nCookies are files with small amount of data which may include an anonymous unique identifier. Cookies are sent to your browser from a website and stored on your device. Tracking technologies also used are beacons, tags, and scripts to collect and track information and to improve and analyze our Service.\r\nYou can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Service.\r\n\r\nExamples of Cookies we use:', 'Session Cookies. We use Session Cookies to operate our Service.\r\nPreference Cookies. We use Preference Cookies to remember your preferences and various settings.\r\nSecurity Cookies. We use Security Cookies for security purposes.'),
(13, 7, 'ar', 'استخدام البيانات', '', 'تستخدم [CompanyName] البيانات التي تم جمعها لأغراض مختلفة :', 'لإعلامك عن تغييرات لخدمتنا.\r\nللسماح لك بالمشاركة في الميزات التفاعلية في خدمتنا عندما تختار القيام بذلك.\r\nلتوفير رعاية العملاء والدعم.\r\nلتقديم تحليل أو معلومات قيمة حتى نتمكن من تحسين الخدمة.\r\nلمراقبة استخدام الخدمة.\r\nللكشف عن المشكلات الفنية ومنعها ومعالجتها.'),
(14, 7, 'en', 'Use of Data', '', '[CompanyName] uses the collected data for various purposes:', 'To provide and maintain the Service.\r\nTo notify you about changes to our Service.\r\nTo allow you to participate in interactive features of our Service when you choose to do so.\r\nTo provide customer care and support.\r\nTo provide analysis or valuable information so that we can improve the Service.\r\nTo monitor the usage of the Service.\r\nTo detect, prevent and address technical issues.'),
(15, 8, 'ar', 'نقل البيانات', '', 'قد يتم نقل معلوماتك - بما في ذلك البيانات الشخصية - إلى أجهزة الكمبيوتر الموجودة خارج الولاية أو المقاطعة أو الدولة أو الولاية الحكومية الأخرى التي قد تختلف فيها قوانين حماية البيانات عن تلك الخاصة باختصاصك القضائي.\r\nإذا كنت متواجدًا خارج مصر واخترت تقديم معلومات لنا، يرجى ملاحظة أننا نقوم بنقل البيانات، بما في ذلك البيانات الشخصية، إلى مصر ومعالجتها هناك.\r\nإن موافقتك على سياسة الخصوصية هذه والتي يتبعها تقديمك لهذه المعلومات تمثل موافقتك على هذا النقل \r\nسوف تتخذ [CompanyName] جميع الخطوات الضرورية بشكل معقول لضمان التعامل مع بياناتك بشكل آمن ووفقًا لسياسة الخصوصية هذه ولن يتم نقل بياناتك الشخصية إلى منظمة أو دولة ما لم تكن هناك ضوابط كافية في مكان بما في ذلك أمن البيانات الخاصة بك وغيرها من المعلومات الشخصية.', ''),
(16, 8, 'en', 'Transfer Of Data', '', 'Your information, including Personal Data, may be transferred to — and maintained on — computers located outside of your state, province, country or other governmental jurisdiction where the data protection laws may differ than those from your jurisdiction.\r\nIf you are located outside Egypt and choose to provide information to us, please note that we transfer the data, including Personal Data, to Egypt and process it there.\r\nYour consent to this Privacy Policy followed by your submission of such information represents your agreement to that transfer.\r\n[CompanyName] will take all steps reasonably necessary to ensure that your data is treated securely and in accordance with this Privacy Policy and no transfer of your Personal Data will take place to an organization or a country unless there are adequate controls in place including the security of your data and other personal information.', ''),
(17, 9, 'ar', 'الكشف عن البيانات', 'المتطلبات القانونية', 'يحق لـ [CompanyName] الإفصاح عن بياناتك الشخصية بحسن نية من أن هذا الإجراء ضروري من أجل:', 'للامتثال لالتزام قانوني\r\nلحماية والدفاع عن حقوق أو ملكية [CompanyName]\r\nلمنع أو التحقيق في أي مخالفات محتملة تتعلق بالخدمة.\r\nلحماية السلامة الشخصية لمستخدمي الخدمة أو الجمهور.\r\nللحماية من المسؤولية القانونية.'),
(18, 9, 'en', 'Disclosure Of Data', 'Legal Requirements', '[CompanyName] may disclose your Personal Data in the good faith belief that such action is necessary to:', 'To comply with a legal obligation.\r\nTo protect and defend the rights or property of [CompanyName]\r\nTo prevent or investigate possible wrongdoing in connection with the Service.\r\nTo protect the personal safety of users of the Service or the public.\r\nTo protect against legal liability.'),
(19, 10, 'ar', 'أمن البيانات', '', 'أمان بياناتك مهم بالنسبة لنا، ولكن تذكر أنه لا توجد طريقة للإرسال عبر الإنترنت، أو طريقة التخزين الإلكترونية آمنة ١٠٠٪. بينما نسعى جاهدين لاستخدام وسائل مقبولة تجاريًا لحماية بياناتك الشخصية، لا يمكننا ضمان أمانها المطلق.', ''),
(20, 10, 'en', 'Security Of Data', '', 'The security of your data is important to us, but remember that no method of transmission over the Internet, or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute security.', ''),
(21, 11, 'ar', 'مقدمي الخدمة', '', 'يجوز لنا أن نوظف شركات وأفراد من أطراف ثالثة لتسهيل خدمتنا (&quot;مزودي الخدمة&quot;)، أو تقديم الخدمة نيابة عنا، لأداء الخدمات المتعلقة بالخدمة أو لمساعدتنا في تحليل كيفية استخدام خدمتنا.\r\nهذه الأطراف الثالثة لديها حق الوصول إلى بياناتك الشخصية فقط لأداء هذه المهام نيابة عنا وتكون ملزمة بعدم الكشف عنها أو استخدامها لأي غرض آخر.', ''),
(22, 11, 'en', 'Service Providers', '', 'We may employ third party companies and individuals to facilitate our Service (&quot;Service Providers&quot;), to provide the Service on our behalf, to perform Service-related services or to assist us in analyzing how our Service is used.\r\nThese third parties have access to your Personal Data only to perform these tasks on our behalf and are obligated not to disclose or use it for any other purpose.', ''),
(23, 12, 'ar', 'تحليلات', '', 'قد نستخدم مزودي خدمة من جهات خارجية لمراقبة وتحليل استخدام خدماتنا.', ''),
(24, 12, 'en', 'Analytics', '', 'We may use third-party Service Providers to monitor and analyze the use of our Service.', ''),
(25, 13, 'ar', 'روابط لمواقع أخرى', '', 'قد تحتوي خدمتنا على روابط إلى مواقع أخرى لا يتم تشغيلها من قبلنا. إذا نقرت على رابط جهة خارجية، فسيتم توجيهك إلى موقع الطرف الثالث هذا. ننصحك بشدة بمراجعة سياسة الخصوصية لكل موقع تزوره.\r\n\r\nليس لدينا أي سيطرة ولا نتحمل أي مسؤولية عن المحتوى أو سياسات الخصوصية أو الممارسات الخاصة بأي مواقع أو خدمات خاصة بطرف ثالث.', ''),
(26, 13, 'en', 'Links To Other Sites', '', 'Our Service may contain links to other sites that are not operated by us. If you click on a third party link, you will be directed to that third party\'s site. We strongly advise you to review the Privacy Policy of every site you visit.\r\n\r\nWe have no control over and assume no responsibility for the content, privacy policies or practices of any third party sites or services.', ''),
(27, 14, 'ar', 'خصوصية الأطفال', '', 'لا تتناول خدمتنا أي شخص دون سن ١٨ عامًا (&quot;الأطفال&quot;).\r\nنحن لا نجمع معلومات التعريف الشخصية من أي شخص دون سن ١٨ عامًا. إذا كنت أحد الوالدين أو الوصي وكنت على علم بأن أطفالك قد زودونا ببيانات شخصية، يرجى الاتصال بنا. إذا علمنا أننا جمعنا بيانات شخصية من الأطفال دون التحقق من موافقة الوالدين، فإننا نتخذ خطوات لإزالة تلك المعلومات من خوادمنا.', ''),
(28, 14, 'en', 'Children\'s Privacy', '', 'Our Service does not address anyone under the age of 18 (&quot;Children&quot;).\r\nWe do not knowingly collect personally identifiable information from anyone under the age of 18. If you are a parent or guardian and you are aware that your Children has provided us with Personal Data, please contact us. If we become aware that we have collected Personal Data from children without verification of parental consent, we take steps to remove that information from our servers.', ''),
(29, 15, 'ar', 'تغييرات سياسة الخصوصية', '', 'يجوز لنا تحديث سياسة الخصوصية الخاصة بنا من وقت لآخر. سنعلمك بأي تغييرات عن طريق نشر سياسة الخصوصية الجديدة على هذه الصفحة.\r\nسنخبرك عبر البريد الإلكتروني و/ أو بإشعار بارز في خدمتنا، قبل أن يصبح التغيير ساريًا وتحديث &quot;تاريخ الفعالية&quot; في أعلى سياسة الخصوصية هذه.\r\nننصحك بمراجعة سياسة الخصوصية هذه بشكل دوري لأية تغييرات. تسري التغييرات التي تطرأ على سياسة الخصوصية هذه عند نشرها على هذه الصفحة.', ''),
(30, 15, 'en', 'Changes To This Privacy Policy', '', 'We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.\r\n\r\nWe will let you know via email and/or a prominent notice on our Service, prior to the change becoming effective and update the &quot;effective date&quot; at the top of this Privacy Policy.\r\n\r\nYou are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page.', ''),
(31, 16, 'ar', 'اتصل بنا', NULL, 'إذا كان لديك أي أسئلة حول سياسة الخصوصية هذه، يرجى الاتصال بنا:', 'البريد الإلكتروني : [WebEmail]'),
(32, 16, 'en', 'Contact Us', NULL, 'If you have any questions about this Privacy Policy, please contact us:', 'Email : [WebEmail]');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(172, '2014_10_12_000000_create_users_back', 1),
(173, '2014_10_12_000000_create_users_table', 1),
(174, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(175, '2014_10_12_100000_create_password_resets_table', 1),
(176, '2019_08_19_000000_create_failed_jobs_table', 1),
(177, '2019_12_13_000001_create_permission_tables', 1),
(178, '2019_12_13_000002_add_names_roles_table', 1),
(179, '2019_12_13_000003_add_names_permissions_table', 1),
(180, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(181, '2019_12_14_000001_create_settings_table', 1),
(182, '2019_12_14_000002_create_menu_table', 1),
(183, '2019_12_14_000003_create_meta_tags_table', 1),
(184, '2019_12_14_000005_create_def_photos_table', 1),
(185, '2019_12_14_000006_create_upload_filters_table', 1),
(186, '2019_12_14_000007_create_upload_filter_sizes_table', 1),
(187, '2019_12_14_000008_create_file_manager_table', 1),
(188, '2019_12_14_000008_create_web_privacies_table', 1),
(189, '2020_01_01_000001_create_page_model_table', 1),
(190, '2021_01_02_000001_create_blog_model_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1),
(2, 'App\\Models\\User', 2),
(2, 'App\\Models\\User', 3),
(2, 'App\\Models\\User', 4),
(2, 'App\\Models\\User', 5),
(2, 'App\\Models\\User', 6),
(2, 'App\\Models\\User', 7),
(2, 'App\\Models\\User', 8),
(2, 'App\\Models\\User', 9),
(2, 'App\\Models\\User', 10),
(2, 'App\\Models\\User', 11),
(2, 'App\\Models\\User', 12),
(2, 'App\\Models\\User', 13),
(2, 'App\\Models\\User', 14),
(2, 'App\\Models\\User', 15),
(2, 'App\\Models\\User', 16),
(2, 'App\\Models\\User', 17),
(2, 'App\\Models\\User', 18),
(2, 'App\\Models\\User', 19),
(2, 'App\\Models\\User', 20),
(2, 'App\\Models\\User', 21),
(2, 'App\\Models\\User', 22),
(2, 'App\\Models\\User', 23),
(2, 'App\\Models\\User', 24),
(2, 'App\\Models\\User', 25),
(2, 'App\\Models\\User', 26);

-- --------------------------------------------------------

--
-- Table structure for table `pagecategory_page`
--

CREATE TABLE `pagecategory_page` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `page_id` bigint(20) UNSIGNED NOT NULL,
  `postion` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pagecategory_page`
--

INSERT INTO `pagecategory_page` (`id`, `category_id`, `page_id`, `postion`) VALUES
(1, 1, 1, 0),
(2, 1, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `page_categories`
--

CREATE TABLE `page_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `deep` int(11) NOT NULL DEFAULT 0,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `postion` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `page_categories`
--

INSERT INTO `page_categories` (`id`, `parent_id`, `deep`, `icon`, `photo`, `photo_thum_1`, `is_active`, `postion`, `created_at`, `updated_at`) VALUES
(1, NULL, 0, NULL, NULL, NULL, 1, 0, '2024-03-30 20:23:23', '2024-03-30 20:23:23');

-- --------------------------------------------------------

--
-- Table structure for table `page_category_translations`
--

CREATE TABLE `page_category_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `page_category_translations`
--

INSERT INTO `page_category_translations` (`id`, `category_id`, `locale`, `slug`, `name`, `des`, `g_title`, `g_des`) VALUES
(1, 1, 'ar', 'الصفحات-الرئيسية', 'الصفحات الرئيسية', 'الصفحات الرئيسية', 'الصفحات الرئيسية', 'الصفحات الرئيسية');

-- --------------------------------------------------------

--
-- Table structure for table `page_pages`
--

CREATE TABLE `page_pages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_type` int(11) DEFAULT 0,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published_at` date DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `page_pages`
--

INSERT INTO `page_pages` (`id`, `user_id`, `is_active`, `photo`, `photo_thum_1`, `url_type`, `youtube`, `published_at`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, NULL, 1, NULL, NULL, 0, NULL, NULL, NULL, '2024-03-30 20:57:45', '2024-03-30 20:57:45'),
(2, NULL, 1, NULL, NULL, 0, NULL, NULL, NULL, '2024-03-30 23:20:47', '2024-03-30 23:20:47');

-- --------------------------------------------------------

--
-- Table structure for table `page_photos`
--

CREATE TABLE `page_photos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `page_id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` int(11) NOT NULL DEFAULT 0,
  `print_photo` int(11) NOT NULL DEFAULT 2,
  `is_default` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `page_photos`
--

INSERT INTO `page_photos` (`id`, `page_id`, `photo`, `photo_thum_1`, `photo_thum_2`, `position`, `print_photo`, `is_default`) VALUES
(6, 2, 'images/pages/2/معايير-تدقيق-المحتوى-في-موضوع-A053kRxpil.webp', 'images/pages/2/معايير-تدقيق-المحتوى-في-موضوع-DZVIq4QY2m.webp', NULL, 0, 2, 0),
(7, 2, 'images/pages/2/معايير-تدقيق-المحتوى-في-موضوع-QIqbccAcV5.webp', 'images/pages/2/معايير-تدقيق-المحتوى-في-موضوع-YBV4d6fJhk.webp', NULL, 0, 2, 0),
(8, 2, 'images/pages/2/معايير-تدقيق-المحتوى-في-موضوع-uDDOkDpjtS.webp', 'images/pages/2/معايير-تدقيق-المحتوى-في-موضوع-VKz530wRZa.webp', NULL, 0, 2, 0),
(9, 2, 'images/pages/2/معايير-تدقيق-المحتوى-في-موضوع-MSQD2o9lzL.webp', 'images/pages/2/معايير-تدقيق-المحتوى-في-موضوع-fGtOdJbUSf.webp', NULL, 0, 2, 0),
(10, 2, 'images/pages/2/معايير-تدقيق-المحتوى-في-موضوع-jozkzxA9E6.webp', 'images/pages/2/معايير-تدقيق-المحتوى-في-موضوع-dnEs9FZqd6.webp', NULL, 0, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `page_photo_translations`
--

CREATE TABLE `page_photo_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `photo_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `des` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `page_photo_translations`
--

INSERT INTO `page_photo_translations` (`id`, `photo_id`, `locale`, `des`) VALUES
(5, 6, 'ar', '<h2>1. مرحلة البحث</h2>\r\n\r\n<p>في هذه المرحلة يتم تحديد الحاجة الحقيقية للمستخدم من خلال اختيار العنوان المناسب وتحري الأسلوب الأمثل للكتابة الذي يضمن الفهم الأفضل والتدرج في المعلومة والحصول عليها بسهولة.</p>'),
(6, 7, 'ar', '<h2>2. مرحلة الكتابة</h2>\r\n\r\n<p>يقوم الكتاب والخبراء في المجالات المتنوعة بكتابة المقالات، استناداً لسياسات المحتوى في شركة موضوع وبالرجوع لمصادر المعلومات ذات الموثوقية العالية.</p>'),
(7, 8, 'ar', '<h2>3. مرحلة التدقيق</h2>\r\n\r\n<p>تخضع جميع المقالات المكتوبة لعدة مراحل من التدقيق والمراجعة من قبل خبراء للتأكد من دقة المعلومات المكتوبة وشموليتها وفائدتها للمستخدم وأصالتها</p>'),
(8, 9, 'ar', '<h2>4. مرحلة استخدام التكنولوجيا المتقدمة</h2>\r\n\r\n<p>حيث يتم استخدام أدوات الذكاء الاصطناعي المطورة من قبل موضوع لتحرير جميع المقالات وتصحيحها.</p>'),
(9, 10, 'ar', '<h2>5. مرحلة المراجعة</h2>\r\n\r\n<p>يقوم فريقنا بشكل دوري، بمراجعة وإثراء المحتوى للتأكد من حداثته ودقته وتلبيته لاحتياجات القراء</p>');

-- --------------------------------------------------------

--
-- Table structure for table `page_translations`
--

CREATE TABLE `page_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `page_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `page_translations`
--

INSERT INTO `page_translations` (`id`, `page_id`, `locale`, `slug`, `name`, `des`, `g_title`, `g_des`, `youtube_title`) VALUES
(1, 1, 'ar', 'من-نحن', 'من نحن', '<h2>موقع msry1.com: وجهتك الأولى للمحتوى العربي المتميز</h2>\r\n\r\n<p>تحت رعاية شركة A Plan، يبرز موقع مصري كواحد من المواقع الاكثر تميزًا في مجموعتنا الإلكترونية، متخصصًا في إثراء المحتوى العربي عبر مختلف جوانب الحياة. يتميز بكونه مصدرًا غنيًا بالمعلومات والمواضيع المتنوعة التي تلبي احتياجات القارئ العربي.</p>\r\n\r\n<h2>لماذا يعد msry1.com خيارك الأمثل للمحتوى العربي الراقي؟</h2>\r\n\r\n<p>يجمع الموقع بين الدقة والمصداقية والعناية بجودة المحتوى، ما يجعله منبرًا مثاليًا للقراء الباحثين عن معلومات موثوقة.</p>\r\n\r\n<h2>إليك بعض الخصائص التي تجعل من موقع مصري إضافة قيمة للمحتوى العربي:</h2>\r\n\r\n<p>1. تفسير الأحلام: يخصص موقع مصري قسمًا لتفسير الأحلام، مما يتيح للزائرين الاستعانة بخبراء لتحليل أحلامهم وإعطاء تفسيرات معمقة تساعدهم على فهم رسائل أحلامهم بوضوح.</p>\r\n\r\n<p>2. تغطية شاملة لمجالات متعددة: يتجاوز نطاق المحتوى في msry1.com تفسير الأحلام ليشمل مجالات مثل الصحة، الجمال، التكنولوجيا، السفر، الثقافة، العلوم، وغيرها. يتيح هذا التنوع للقراء العثور على مقالات تثقيفية ومفيدة تسهم في إثراء معارفهم.</p>\r\n\r\n<p>3. فريق من الكتاب المتمرسين: يتألف من كتاب وخبراء متخصصين في مجالاتهم، ما يضمن الدقة والجودة العالية للمحتوى المقدم. يسعى الفريق جاهدًا لتقديم محتوى فريد وموثوق يلبي تطلعات القراء.</p>\r\n\r\n<p>4. تجربة تصفح مريحة وواجهة سلسة: تلتزم شركة A Plan بتوفير تجربة تصفح فائقة السهولة عبر واجهة msry1.com البسيطة والمنظمة، ما يمكن القراء من الوصول إلى المعلومات المطلوبة بكل يسر وسرعة.</p>\r\n\r\n<p>باختصار، يقدم msry1.com محتوى عربياً متخصصاً وعاماً ذو قيمة عالية في مجالات متنوعة، ما يجعله مصدراً موثوقاً للقراء الراغبين٫ في تعزيز معرفتهم.</p>\r\n\r\n<p>باختصار، يقدم msry1.com محتوى عربياً متخصصاً وعاماً ذو قيمة عالية في مجالات متنوعة، ما يجعله مصدراً موثوقاً للقراء الراغبين٫ في تعزيز معرفتهم.</p>\r\n\r\n<h2>إذا كنت تسعى لمحتوى عربي متميز يلبي اهتماماتك، فإن موقع مصري هو وجهتك المثالية. قائمة: مميزات موقع msry1.com كمكان موثوق للاستفادة من المحتوى العربي</h2>\r\n\r\n<ol>\r\n	<li><strong>تنوع في المحتوى :</strong> يقدم مجموعة متنوعة من المواضيع والمقالات التي تلبي اهتمامات القراء العرب.</li>\r\n	<li><strong>مصداقية عالية :</strong> يعتبر مصدرًا موثوقًا وموثوقًا به للحصول على معلومات دقيقة وموثوقة.</li>\r\n	<li><strong>تحديث مستمر: </strong>يتم تحديث المحتوى على موقع msry1.com بانتظام لضمان توافر المعلومات الحديثة والمهمة.</li>\r\n	<li><strong>دعم للثقافة العربية : </strong>يساهم في نشر وتعزيز الثقافة العربية واللغة العربية من خلال مقالاته وتقاريره.</li>\r\n	<li><strong>سهولة الوصول : </strong>يتميز&nbsp; بتصميم يسهل على القراء العثور على المحتوى بسهولة ويسر.</li>\r\n</ol>\r\n\r\n<h2>فريق العمل</h2>\r\n\r\n<p>يتألف فريق المحررين من خبراء يعملون بكفاءة عالية في تقديم محتوى دقيق وموثوق في جميع المجالات التي يغطيها الموقع. يتمتع كل محرر بتخصص ومعرفة واسعة في مجاله، مما يضمن جودة المحتوى المقدم.الجودة والاحترافية يحرص Msry1.com على تقديم محتوى ذو جودة عالية، ملتزماً بمعايير صارمة في التحرير والتدقيق لضمان الدقة والمصداقية في تقديم المعلومات بأسلوب سلس ومفهوم.</p>\r\n\r\n<h2>اتصل بنا</h2>\r\n\r\n<p>للتواصل مع فريق موقع مصري، يمكنكم استخدام البريد الإلكتروني info@msry1.com أو متابعتنا على وسائل التواصل الاجتماعي لإرسال استفساراتكم. نحن ملتزمون بتحسين خدماتنا وتلبية توقعات قرائنا دائمًا.</p>\r\n\r\n<p>&nbsp;</p>', 'من نحن', 'من نحن', NULL),
(2, 2, 'ar', 'معايير-تدقيق-المحتوى-في-موضوع', 'معايير تدقيق المحتوى في موضوع', '<p style=\"text-align:center\">في موضوع، نحرص على أن يمر المحتوى بعدة مراحل والتي تضمن لنا تحقيق أعلى معايير الجودة والدقة، وتقديم الفائدة للمستخدم وتوفير محتوى معاصر يجيب على أسئلة القارئ العربي، أهمها :</p>', 'معايير تدقيق المحتوى في موضوع', 'معايير تدقيق المحتوى في موضوع', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cat_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `cat_id`, `name`, `name_ar`, `name_en`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'users', 'users_view', 'عرض', 'View', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(2, 'users', 'users_add', 'اضافة', 'Add', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(3, 'users', 'users_edit', 'تعديل', 'Edit', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(4, 'users', 'users_delete', 'حذف', 'Delete', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(5, 'users', 'users_restore', 'استعادة المحذوف', 'Restore', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(6, 'roles', 'roles_view', 'عرض', 'View', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(7, 'roles', 'roles_add', 'اضافة', 'Add', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(8, 'roles', 'roles_edit', 'تعديل', 'Edit', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(9, 'roles', 'roles_delete', 'حذف', 'Delete', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(10, 'roles', 'roles_update_permissions', 'تعديل صلاحيات المجموعة', 'Roles Update Permissions', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(11, 'Blog', 'Blog_view', 'عرض', 'View', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(12, 'Blog', 'Blog_add', 'اضافة', 'Add', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(13, 'Blog', 'Blog_edit', 'تعديل', 'Edit', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(14, 'Blog', 'Blog_delete', 'حذف', 'Delete', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(15, 'Blog', 'Blog_edit_slug', 'تعديل الرابط', 'Edit Slug', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(16, 'Blog', 'Blog_restore', 'استعادة المحذوف', 'Restore', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(17, 'Blog', 'Blog_teamleader', 'مشرف عام', 'Team Leader', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(18, 'Pages', 'Pages_view', 'عرض', 'View', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(19, 'Pages', 'Pages_add', 'اضافة', 'Add', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(20, 'Pages', 'Pages_edit', 'تعديل', 'Edit', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(21, 'Pages', 'Pages_delete', 'حذف', 'Delete', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(22, 'Pages', 'Pages_edit_slug', 'تعديل الرابط', 'Edit Slug', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(23, 'Pages', 'Pages_restore', 'استعادة المحذوف', 'Restore', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(24, 'config', 'config_view', 'عرض الاعدادات', 'Setting View', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(25, 'config', 'config_add', 'اضافة', 'Add', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(26, 'config', 'config_edit', 'تعديل', 'Edit', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(27, 'config', 'config_delete', 'حذف', 'Delete', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(28, 'config', 'config_restore', 'استعادة المحذوف', 'Restore', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(29, 'config', 'config_website', 'اعدادات الموقع', 'Web Site Setting', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(30, 'config', 'config_defPhoto_view', 'الصور الافتراضية', 'View', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(31, 'config', 'config_upFilter_view', 'فلاتر الصور', 'View', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(32, 'config', 'config_newsletter', 'القائمة البريدية', 'News Letter', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(33, 'config', 'adminlang_view', 'ملفات لغة التحكم', 'Admin Lang File', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(34, 'config', 'weblang_view', 'ملفات لغة الموقع', 'Web Lang File', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(35, 'config', 'sitemap_view', 'SiteMap', 'SiteMap', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(36, 'config', 'config_meta_view', 'ميتا تاج', 'Meta', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(37, 'config', 'config_web_privacy', 'سياسية الاستخدام', 'Web Privacy', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(38, 'FileManager', 'FileManager_view', 'عرض', 'View', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(39, 'FileManager', 'FileManager_add', 'اضافة', 'Add', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(40, 'FileManager', 'FileManager_edit', 'تعديل', 'Edit', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00'),
(41, 'FileManager', 'FileManager_delete', 'حذف', 'Delete', 'web', '2024-07-23 10:56:00', '2024-07-23 10:56:00');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `name_ar`, `name_en`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'ادمن كامل الصلاحيات', 'Full Admin Permission ', 'web', '2024-07-23 10:56:01', '2024-07-23 10:56:01'),
(2, 'editor', 'محرر', 'editor', 'web', '2024-07-23 10:56:01', '2024-07-23 10:56:01'),
(3, 'supervisor', 'مشرف', 'supervisor', 'web', '2024-07-23 10:56:01', '2024-07-23 10:56:01');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(11, 2),
(12, 1),
(12, 2),
(13, 1),
(13, 2),
(14, 1),
(14, 2),
(15, 1),
(15, 2),
(16, 1),
(16, 2),
(17, 1),
(17, 2),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(41, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `roles_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `slug`, `email`, `phone`, `photo`, `photo_thum_1`, `roles_name`, `status`, `email_verified_at`, `password`, `des`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'هانى درويش', 'هانى-درويش', 'hany.freestyle4u@gmail.com', NULL, NULL, NULL, '[\"admin\"]', 1, NULL, '$2y$10$BM7OxyOn95v6SJWVUKJg.OFvQ76wOiiSEajy.FViTGGoQmVDKOR.u', NULL, NULL, '2024-07-23 10:56:01', '2024-07-23 10:56:01', NULL),
(2, 'Doha Gamal', 'doha-gamal', 'doha-gamal@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$PbIOpcyDyUpCL/ZPcOXdq.A3l6DvF7WcnSEJNBPeWgnifv0tpXcG6', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Doha Gamal، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:01', '2024-07-23 13:56:01', NULL),
(3, 'Doha Hashem', 'doha-hashem', 'doha-hashem@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$ePw844V9TQnOfH4BHNoZOeQxbl99p87325lW9ks234R0k3wHpCvgK', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Doha Hashem، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:01', '2024-07-23 13:56:01', NULL),
(4, 'Omnia Samir', 'omnia-samir', 'omnia-samir@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$xVQZAgerjOZwMn3waHr/3.SSasttOLT7AqxspmgO.8F7ri9B.I8i6', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Omnia Samir، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:01', '2024-07-23 13:56:01', NULL),
(5, 'Samar Sami', 'samar-sami', 'samar-sami@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$PVD9sw92q2nfuE8SSWBjyeJ3KG4JT1064AiBLAlnNYLWkxItofECG', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Samar Sami، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:01', '2024-07-23 13:56:01', NULL),
(6, 'Nancy', 'nancy', 'Nancy@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$jS6W7j352RpZgCAXelNjYele4DetqrC29J9Uhj1wYh7hAw/IGSD3q', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Nancy، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:01', '2024-07-23 13:56:01', NULL),
(7, 'Aya Sanad', 'aya-sanad', 'Aya-Sanad@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$akeL2vMai0JhE4Pw2GW77uv9wAiyxOGs1xAqLtLPe1txbHlvZoD.S', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Aya Sanad، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:01', '2024-07-23 13:56:01', NULL),
(8, 'Dina Shoaib', 'dina-shoaib', 'Dina-Shoaib@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$QIBHuspHQNyZWg/0SuGl2elu/04iow6lS9jB0iIj6aYLHI9TzY9c.', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Dina Shoaib، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:01', '2024-07-23 13:56:01', NULL),
(9, 'Asmaa', 'asmaa', 'Asmaa@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$dfy6GOdQF5Zv0IW.0rHrRe8d3y0PAyZDP/s6GrjJ3zxI4NjHR4hs2', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Asmaa، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:01', '2024-07-23 13:56:01', NULL),
(10, 'Esraa Hussien', 'esraa-hussien', 'Esraa-Hussien@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$aXwR6LKOY9HXO7zMndEf3ePLfOBAYQKL/9F0zAjEIR0XlWcZH6clG', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Esraa Hussien، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:01', '2024-07-23 13:56:01', NULL),
(11, 'Islam Salah', 'islam-salah', 'Islam-Salah@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$FDNwvrpKQ61zJtz9q4wY7uw5fJVJ4FR8dAwILo.FAIE8YZzwu2IWm', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Islam Salah، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:01', '2024-07-23 13:56:01', NULL),
(12, 'Shaimaa Khalid', 'shaimaa-khalid', 'Shaimaa-Khalid@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$mWjP4tPSs6b2RqjbnMrNhePH12VW0aep5Mkmi3pONoKJVe6Ld3BdC', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Shaimaa Khalid، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:01', '2024-07-23 13:56:01', NULL),
(13, 'Mohamed Sheref', 'mohamed-sheref', 'Mohamed-Sheref@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$7VEL1TFBoJ0B27aniEXGlOmLh8.P.POD2.9lFGXb4rGfwX8nceOMy', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Mohamed Sheref، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:01', '2024-07-23 13:56:01', NULL),
(14, 'mirna', 'mirna', 'mirna@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$I8NJTxlsUTWF14xIZNolKOPUo24ceahgf2zRS/NqhgNJ3NG2a1ptW', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا mirna، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:01', '2024-07-23 13:56:01', NULL),
(15, 'radwa', 'radwa', 'radwa@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$nOmiS8aFcBPppiJ2AK5Ij.Cz8SvS7zx/s9cDGFtCcZIis7g6OHTbe', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا radwa، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:01', '2024-07-23 13:56:01', NULL),
(16, 'aya', 'aya', 'aya@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$hz/eFUcdFcUm1rlMBt5lTesTePAuTIZcrrvslKFF515gVHouIQ3PW', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا aya، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:01', '2024-07-23 13:56:01', NULL),
(17, 'Rana Ehab', 'rana-ehab', 'Rana-Ehab@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$XKiayf6c1rjOvAhM4jfcaOzfzIsG9yYjT8JH58Io2NE3lAJYfb9rC', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Rana Ehab، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:01', '2024-07-23 13:56:01', NULL),
(18, 'rehab', 'rehab', 'rehab@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$v8yS4oZDQQM3OV0HfjU5WenGcjOi2i4CpHRoUKvWQf5nvqSrNtZ1C', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا rehab، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:01', '2024-07-23 13:56:01', NULL),
(19, 'Mostafa Ahmed', 'mostafa-ahmed', 'Mostafa-Ahmed@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$/jYhcF56.dgDGT6jR0PYx.e/A7qbssNZgOLYOC0JSO7E5yz3j89Um', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Mostafa Ahmed، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:02', '2024-07-23 13:56:02', NULL),
(20, 'mohamed elsharkawy', 'mohamed-elsharkawy', 'mohamed-elsharkawy@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$71QcK1eGooAfX1q7hMJM4eFLli0/SyYndE7pDCuFEXniKc9v8OJEi', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا mohamed elsharkawy، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:02', '2024-07-23 13:56:02', NULL),
(21, 'Mohamed Sharkawy', 'mohamed-sharkawy', 'Mohamed-Sharkawy@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$avIiGsv9WawSnJI1qZ07yebRUibtKOrz2yd0vQIWg3fwYV5zKAzyS', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Mohamed Sharkawy، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:02', '2024-07-23 13:56:02', NULL),
(22, 'Nora Hashem', 'nora-hashem', 'Nora-Hashem@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$OvPqZDJU664Kn96KDvxmu.9RrXdxo5AvRapCYiqyg/0PjW1ZXLJGS', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Nora Hashem، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:02', '2024-07-23 13:56:02', NULL),
(23, 'Amira Amira', 'amira-amira', 'Amira@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$ATbUZZPwdd8AtD79ljLvT.mJSz1EUhG148tCQk3Hx5cMbdW.CYOcq', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Amira Amira، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:02', '2024-07-23 13:56:02', NULL),
(24, 'Habiba', 'habiba', 'Habiba@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$wGvezqZQsGryxn.sWnIsfOa1r5YQZA9ha0biHoJPnL9P75EjUfmDG', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Habiba، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:02', '2024-07-23 13:56:02', NULL),
(25, 'Habiba Gamal', 'habiba-gamal', 'Habiba-Gamal@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$wLJBGqWaPOYOAEeIh7Jc2uLWLvUWiMZ1Q/b5qFLRlCQIRuXKLwJxS', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Habiba Gamal، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:02', '2024-07-23 13:56:02', NULL),
(26, 'Habiba Ayman', 'habiba-ayman', 'Habiba-Ayman@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$C05AbRdKaO1SueOEKUFDj.aEzs5yoEKc8P0Aat.wFWfh/nkAsemuq', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Habiba Ayman، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-23 13:56:02', '2024-07-23 13:56:02', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_back`
--

CREATE TABLE `users_back` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `roles_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users_back`
--

INSERT INTO `users_back` (`id`, `name`, `slug`, `email`, `phone`, `photo`, `photo_thum_1`, `roles_name`, `status`, `email_verified_at`, `password`, `des`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'هانى درويش', 'هانى-درويش', 'hany.freestyle4u@gmail.com', NULL, NULL, NULL, '[\"admin\"]', 1, NULL, '$2y$10$vsqUxVscpzBXWEm6S9Fyfum2kmRmYFRj6CdEFT.yY5xoichE/c.wa', NULL, NULL, '2024-07-17 13:59:31', '2024-07-17 13:59:31', NULL),
(2, 'Doha Gamal', 'doha-gamal', 'doha-gamal@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$PbIOpcyDyUpCL/ZPcOXdq.A3l6DvF7WcnSEJNBPeWgnifv0tpXcG6', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Doha Gamal، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:32', '2024-07-17 13:59:32', NULL),
(3, 'Doha Hashem', 'doha-hashem', 'doha-hashem@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$ePw844V9TQnOfH4BHNoZOeQxbl99p87325lW9ks234R0k3wHpCvgK', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Doha Hashem، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:32', '2024-07-17 13:59:32', NULL),
(4, 'Omnia Samir', 'omnia-samir', 'omnia-samir@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$xVQZAgerjOZwMn3waHr/3.SSasttOLT7AqxspmgO.8F7ri9B.I8i6', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Omnia Samir، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:32', '2024-07-17 13:59:32', NULL),
(5, 'Samar Sami', 'samar-sami', 'samar-sami@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$PVD9sw92q2nfuE8SSWBjyeJ3KG4JT1064AiBLAlnNYLWkxItofECG', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Samar Sami، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:32', '2024-07-17 13:59:32', NULL),
(6, 'Nancy', 'nancy', 'Nancy@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$jS6W7j352RpZgCAXelNjYele4DetqrC29J9Uhj1wYh7hAw/IGSD3q', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Nancy، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:32', '2024-07-17 13:59:32', NULL),
(7, 'Aya Sanad', 'aya-sanad', 'Aya-Sanad@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$akeL2vMai0JhE4Pw2GW77uv9wAiyxOGs1xAqLtLPe1txbHlvZoD.S', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Aya Sanad، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:32', '2024-07-17 13:59:32', NULL),
(8, 'Dina Shoaib', 'dina-shoaib', 'Dina-Shoaib@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$QIBHuspHQNyZWg/0SuGl2elu/04iow6lS9jB0iIj6aYLHI9TzY9c.', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Dina Shoaib، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:32', '2024-07-17 13:59:32', NULL),
(9, 'Asmaa', 'asmaa', 'Asmaa@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$dfy6GOdQF5Zv0IW.0rHrRe8d3y0PAyZDP/s6GrjJ3zxI4NjHR4hs2', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Asmaa، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:33', '2024-07-17 13:59:33', NULL),
(10, 'Esraa Hussien', 'esraa-hussien', 'Esraa-Hussien@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$aXwR6LKOY9HXO7zMndEf3ePLfOBAYQKL/9F0zAjEIR0XlWcZH6clG', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Esraa Hussien، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:33', '2024-07-17 13:59:33', NULL),
(11, 'Islam Salah', 'islam-salah', 'Islam-Salah@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$FDNwvrpKQ61zJtz9q4wY7uw5fJVJ4FR8dAwILo.FAIE8YZzwu2IWm', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Islam Salah، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:33', '2024-07-17 13:59:33', NULL),
(12, 'Shaimaa Khalid', 'shaimaa-khalid', 'Shaimaa-Khalid@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$mWjP4tPSs6b2RqjbnMrNhePH12VW0aep5Mkmi3pONoKJVe6Ld3BdC', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Shaimaa Khalid، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:33', '2024-07-17 13:59:33', NULL),
(13, 'Mohamed Sheref', 'mohamed-sheref', 'Mohamed-Sheref@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$7VEL1TFBoJ0B27aniEXGlOmLh8.P.POD2.9lFGXb4rGfwX8nceOMy', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Mohamed Sheref، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:33', '2024-07-17 13:59:33', NULL),
(14, 'mirna', 'mirna', 'mirna@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$I8NJTxlsUTWF14xIZNolKOPUo24ceahgf2zRS/NqhgNJ3NG2a1ptW', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا mirna، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:33', '2024-07-17 13:59:33', NULL),
(15, 'radwa', 'radwa', 'radwa@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$nOmiS8aFcBPppiJ2AK5Ij.Cz8SvS7zx/s9cDGFtCcZIis7g6OHTbe', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا radwa، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:33', '2024-07-17 13:59:33', NULL),
(16, 'aya', 'aya', 'aya@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$hz/eFUcdFcUm1rlMBt5lTesTePAuTIZcrrvslKFF515gVHouIQ3PW', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا aya، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:34', '2024-07-17 13:59:34', NULL),
(17, 'Rana Ehab', 'rana-ehab', 'Rana-Ehab@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$XKiayf6c1rjOvAhM4jfcaOzfzIsG9yYjT8JH58Io2NE3lAJYfb9rC', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Rana Ehab، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:34', '2024-07-17 13:59:34', NULL),
(18, 'rehab', 'rehab', 'rehab@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$v8yS4oZDQQM3OV0HfjU5WenGcjOi2i4CpHRoUKvWQf5nvqSrNtZ1C', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا rehab، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:34', '2024-07-17 13:59:34', NULL),
(19, 'Mostafa Ahmed', 'mostafa-ahmed', 'Mostafa-Ahmed@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$/jYhcF56.dgDGT6jR0PYx.e/A7qbssNZgOLYOC0JSO7E5yz3j89Um', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Mostafa Ahmed، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:34', '2024-07-17 13:59:34', NULL),
(20, 'mohamed elsharkawy', 'mohamed-elsharkawy', 'mohamed-elsharkawy@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$71QcK1eGooAfX1q7hMJM4eFLli0/SyYndE7pDCuFEXniKc9v8OJEi', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا mohamed elsharkawy، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:34', '2024-07-17 13:59:34', NULL),
(21, 'Mohamed Sharkawy', 'mohamed-sharkawy', 'Mohamed-Sharkawy@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$avIiGsv9WawSnJI1qZ07yebRUibtKOrz2yd0vQIWg3fwYV5zKAzyS', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Mohamed Sharkawy، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:34', '2024-07-17 13:59:34', NULL),
(22, 'Nora Hashem', 'nora-hashem', 'Nora-Hashem@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$OvPqZDJU664Kn96KDvxmu.9RrXdxo5AvRapCYiqyg/0PjW1ZXLJGS', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Nora Hashem، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:34', '2024-07-17 13:59:34', NULL),
(23, 'Amira Amira', 'amira-amira', 'Amira@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$ATbUZZPwdd8AtD79ljLvT.mJSz1EUhG148tCQk3Hx5cMbdW.CYOcq', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Amira Amira، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:34', '2024-07-17 13:59:34', NULL),
(24, 'Habiba', 'habiba', 'Habiba@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$wGvezqZQsGryxn.sWnIsfOa1r5YQZA9ha0biHoJPnL9P75EjUfmDG', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Habiba، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:35', '2024-07-17 13:59:35', NULL),
(25, 'Habiba Gamal', 'habiba-gamal', 'Habiba-Gamal@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$wLJBGqWaPOYOAEeIh7Jc2uLWLvUWiMZ1Q/b5qFLRlCQIRuXKLwJxS', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Habiba Gamal، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:35', '2024-07-17 13:59:35', NULL),
(26, 'Habiba Ayman', 'habiba-ayman', 'Habiba-Ayman@islamic-dreams-interpretation.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$C05AbRdKaO1SueOEKUFDj.aEzs5yoEKc8P0Aat.wFWfh/nkAsemuq', 'مرحبًا بكم في عالمي، حيث الكلمات ترشدكم إلى فهم أعماق أحلامكم. أنا Habiba Ayman، المتخصص في تفسير الأحلام وكتابة المقالات المعلوماتية التي تضيء الجوانب المخفية وراء رموز وقصص أحلامنا.\nبخلفية أكاديمية في علم النفس وعلم الاجتماع، أعمق في الأبعاد النفسية والثقافية التي تشكل عوالم أحلامنا. أسعى من خلال كتاباتي لتقديم تحليلات دقيقة ومفهومة، تساعد القراء على ربط تجاربهم الحلمية بواقع حياتهم.\nمن خلال مقالاتي، ستجدون دليلًا شاملًا لفهم الرسائل الخفية في الأحلام وكيفية تطبيق هذه الفهوم في تعزيز النمو الشخصي والوعي الذاتي. انضموا إلي في هذه الرحلة الاستكشافية لعالم الأحلام، حيث كل حلم هو بوابة لاكتشاف الذات.', NULL, '2024-07-17 13:59:35', '2024-07-17 13:59:35', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blogcategory_blog`
--
ALTER TABLE `blogcategory_blog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `blogcategory_blog_category_id_foreign` (`category_id`),
  ADD KEY `blogcategory_blog_blog_id_foreign` (`blog_id`);

--
-- Indexes for table `blog_categories`
--
ALTER TABLE `blog_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_category_translations`
--
ALTER TABLE `blog_category_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `blog_category_translations_category_id_locale_unique` (`category_id`,`locale`),
  ADD UNIQUE KEY `blog_category_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `blog_category_translations_locale_index` (`locale`);

--
-- Indexes for table `blog_post`
--
ALTER TABLE `blog_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_post_review`
--
ALTER TABLE `blog_post_review`
  ADD PRIMARY KEY (`id`),
  ADD KEY `blog_post_review_blog_id_foreign` (`blog_id`);

--
-- Indexes for table `blog_tags`
--
ALTER TABLE `blog_tags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_tags_post`
--
ALTER TABLE `blog_tags_post`
  ADD PRIMARY KEY (`id`),
  ADD KEY `blog_tags_post_tag_id_foreign` (`tag_id`),
  ADD KEY `blog_tags_post_blog_id_foreign` (`blog_id`);

--
-- Indexes for table `blog_tags_translations`
--
ALTER TABLE `blog_tags_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `blog_tags_translations_tag_id_locale_unique` (`tag_id`,`locale`),
  ADD UNIQUE KEY `blog_tags_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `blog_tags_translations_locale_index` (`locale`);

--
-- Indexes for table `blog_translations`
--
ALTER TABLE `blog_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `blog_translations_blog_id_locale_unique` (`blog_id`,`locale`),
  ADD UNIQUE KEY `blog_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `blog_translations_locale_index` (`locale`);

--
-- Indexes for table `config_def_photos`
--
ALTER TABLE `config_def_photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_file_manager`
--
ALTER TABLE `config_file_manager`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_menu`
--
ALTER TABLE `config_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_meta_tags`
--
ALTER TABLE `config_meta_tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_meta_tags_cat_id_unique` (`cat_id`);

--
-- Indexes for table `config_meta_tag_translations`
--
ALTER TABLE `config_meta_tag_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_meta_tag_translations_meta_tag_id_locale_unique` (`meta_tag_id`,`locale`),
  ADD KEY `config_meta_tag_translations_locale_index` (`locale`);

--
-- Indexes for table `config_settings`
--
ALTER TABLE `config_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_setting_translations_setting_id_locale_unique` (`setting_id`,`locale`),
  ADD KEY `config_setting_translations_locale_index` (`locale`);

--
-- Indexes for table `config_upload_filters`
--
ALTER TABLE `config_upload_filters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `config_upload_filter_sizes_filter_id_foreign` (`filter_id`);

--
-- Indexes for table `config_web_privacies`
--
ALTER TABLE `config_web_privacies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_web_privacy_translations`
--
ALTER TABLE `config_web_privacy_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_web_privacy_translations_privacy_id_locale_unique` (`privacy_id`,`locale`),
  ADD KEY `config_web_privacy_translations_locale_index` (`locale`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `pagecategory_page`
--
ALTER TABLE `pagecategory_page`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pagecategory_page_category_id_foreign` (`category_id`),
  ADD KEY `pagecategory_page_page_id_foreign` (`page_id`);

--
-- Indexes for table `page_categories`
--
ALTER TABLE `page_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page_category_translations`
--
ALTER TABLE `page_category_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `page_category_translations_category_id_locale_unique` (`category_id`,`locale`),
  ADD UNIQUE KEY `page_category_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `page_category_translations_locale_index` (`locale`);

--
-- Indexes for table `page_pages`
--
ALTER TABLE `page_pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page_photos`
--
ALTER TABLE `page_photos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `page_photos_page_id_foreign` (`page_id`);

--
-- Indexes for table `page_photo_translations`
--
ALTER TABLE `page_photo_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `page_photo_translations_photo_id_locale_unique` (`photo_id`,`locale`),
  ADD KEY `page_photo_translations_locale_index` (`locale`);

--
-- Indexes for table `page_translations`
--
ALTER TABLE `page_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `page_translations_page_id_locale_unique` (`page_id`,`locale`),
  ADD UNIQUE KEY `page_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `page_translations_locale_index` (`locale`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_slug_unique` (`slug`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `users_back`
--
ALTER TABLE `users_back`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_back_slug_unique` (`slug`),
  ADD UNIQUE KEY `users_back_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blogcategory_blog`
--
ALTER TABLE `blogcategory_blog`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `blog_categories`
--
ALTER TABLE `blog_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `blog_category_translations`
--
ALTER TABLE `blog_category_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `blog_post`
--
ALTER TABLE `blog_post`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `blog_post_review`
--
ALTER TABLE `blog_post_review`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `blog_tags`
--
ALTER TABLE `blog_tags`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blog_tags_post`
--
ALTER TABLE `blog_tags_post`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blog_tags_translations`
--
ALTER TABLE `blog_tags_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blog_translations`
--
ALTER TABLE `blog_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `config_def_photos`
--
ALTER TABLE `config_def_photos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `config_file_manager`
--
ALTER TABLE `config_file_manager`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `config_menu`
--
ALTER TABLE `config_menu`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `config_meta_tags`
--
ALTER TABLE `config_meta_tags`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `config_meta_tag_translations`
--
ALTER TABLE `config_meta_tag_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `config_settings`
--
ALTER TABLE `config_settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `config_upload_filters`
--
ALTER TABLE `config_upload_filters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `config_web_privacies`
--
ALTER TABLE `config_web_privacies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `config_web_privacy_translations`
--
ALTER TABLE `config_web_privacy_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=191;

--
-- AUTO_INCREMENT for table `pagecategory_page`
--
ALTER TABLE `pagecategory_page`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `page_categories`
--
ALTER TABLE `page_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `page_category_translations`
--
ALTER TABLE `page_category_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `page_pages`
--
ALTER TABLE `page_pages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `page_photos`
--
ALTER TABLE `page_photos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `page_photo_translations`
--
ALTER TABLE `page_photo_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `page_translations`
--
ALTER TABLE `page_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `users_back`
--
ALTER TABLE `users_back`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `blogcategory_blog`
--
ALTER TABLE `blogcategory_blog`
  ADD CONSTRAINT `blogcategory_blog_blog_id_foreign` FOREIGN KEY (`blog_id`) REFERENCES `blog_post` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `blogcategory_blog_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `blog_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `blog_category_translations`
--
ALTER TABLE `blog_category_translations`
  ADD CONSTRAINT `blog_category_translations_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `blog_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `blog_post_review`
--
ALTER TABLE `blog_post_review`
  ADD CONSTRAINT `blog_post_review_blog_id_foreign` FOREIGN KEY (`blog_id`) REFERENCES `blog_post` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `blog_tags_post`
--
ALTER TABLE `blog_tags_post`
  ADD CONSTRAINT `blog_tags_post_blog_id_foreign` FOREIGN KEY (`blog_id`) REFERENCES `blog_post` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `blog_tags_post_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `blog_tags` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `blog_tags_translations`
--
ALTER TABLE `blog_tags_translations`
  ADD CONSTRAINT `blog_tags_translations_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `blog_tags` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `blog_translations`
--
ALTER TABLE `blog_translations`
  ADD CONSTRAINT `blog_translations_blog_id_foreign` FOREIGN KEY (`blog_id`) REFERENCES `blog_post` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_meta_tag_translations`
--
ALTER TABLE `config_meta_tag_translations`
  ADD CONSTRAINT `config_meta_tag_translations_meta_tag_id_foreign` FOREIGN KEY (`meta_tag_id`) REFERENCES `config_meta_tags` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  ADD CONSTRAINT `config_setting_translations_setting_id_foreign` FOREIGN KEY (`setting_id`) REFERENCES `config_settings` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  ADD CONSTRAINT `config_upload_filter_sizes_filter_id_foreign` FOREIGN KEY (`filter_id`) REFERENCES `config_upload_filters` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_web_privacy_translations`
--
ALTER TABLE `config_web_privacy_translations`
  ADD CONSTRAINT `config_web_privacy_translations_privacy_id_foreign` FOREIGN KEY (`privacy_id`) REFERENCES `config_web_privacies` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `pagecategory_page`
--
ALTER TABLE `pagecategory_page`
  ADD CONSTRAINT `pagecategory_page_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `page_categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `pagecategory_page_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `page_pages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `page_category_translations`
--
ALTER TABLE `page_category_translations`
  ADD CONSTRAINT `page_category_translations_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `page_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `page_photos`
--
ALTER TABLE `page_photos`
  ADD CONSTRAINT `page_photos_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `page_pages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `page_photo_translations`
--
ALTER TABLE `page_photo_translations`
  ADD CONSTRAINT `page_photo_translations_photo_id_foreign` FOREIGN KEY (`photo_id`) REFERENCES `page_photos` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `page_translations`
--
ALTER TABLE `page_translations`
  ADD CONSTRAINT `page_translations_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `page_pages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
